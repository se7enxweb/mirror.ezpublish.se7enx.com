<?php
//
// Created on: <28-Jan-2004 16:22:02 dr>
//
// SOFTWARE NAME: eZ Publish
// SOFTWARE RELEASE: 4.0.1
// BUILD VERSION: 22260
// COPYRIGHT NOTICE: Copyright (C) 1999-2008 eZ Systems AS
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//

include ('lib/ezdbschema/classes/ezdbschema.php');
include ('lib/ezdbschema/classes/ezdbschemachecker.php');

$dbschema1 = new eZDbSchema();
$schema1 = $dbschema1->readArray( '/tmp/schema1.php' );

$dbschema2 = new eZDbSchema();
$schema2 = $dbschema2->readArray( '/tmp/schema2.php' );

$differences = eZDbSchemaChecker::diff( $schema1, $schema2 ); /* empty 2nd param force new script */

var_dump($differences);
eZDbSchema::writeUpgradeFile( $differences, 'schema-diff.php' );

?>
