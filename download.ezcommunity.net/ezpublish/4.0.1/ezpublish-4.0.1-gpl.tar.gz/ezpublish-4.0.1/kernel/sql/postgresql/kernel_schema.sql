










CREATE SEQUENCE ezapprove_items_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezbasket_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezcollab_group_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezcollab_item_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezcollab_item_message_link_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezcollab_notification_rule_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezcollab_profile_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezcollab_simple_message_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezcontentbrowsebookmark_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezcontentbrowserecent_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezcontentclass_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezcontentclass_attribute_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezcontentclassgroup_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezcontentobject_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezcontentobject_attribute_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezcontentobject_link_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezcontentobject_tree_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezcontentobject_version_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezcurrencydata_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezdiscountrule_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezdiscountsubrule_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezenumvalue_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezforgot_password_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezgeneral_digest_user_settings_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezimagefile_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezinfocollection_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezinfocollection_attribute_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezisbn_group_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezisbn_group_range_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezisbn_registrant_range_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezkeyword_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezkeyword_attribute_link_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezmessage_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezmodule_run_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezmultipricedata_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE eznode_assignment_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE eznotificationcollection_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE eznotificationcollection_item_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE eznotificationevent_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezoperation_memento_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezorder_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezorder_item_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezorder_status_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezorder_status_history_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezpackage_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezpaymentobject_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezpdf_export_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezpolicy_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezpolicy_limitation_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezpolicy_limitation_value_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezpreferences_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezproductcategory_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezproductcollection_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezproductcollection_item_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezproductcollection_item_opt_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezrole_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezrss_export_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezrss_export_item_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezrss_import_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezsearch_object_word_link_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezsearch_return_count_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezsearch_search_phrase_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezsearch_word_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezsection_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezsubtree_notification_rule_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE eztrigger_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezurl_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezurlalias_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezurlwildcard_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezuser_accountkey_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezuser_discountrule_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezuser_role_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezvatrule_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezvattype_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezwaituntildatevalue_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezwishlist_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezworkflow_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezworkflow_assign_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezworkflow_event_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezworkflow_group_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE SEQUENCE ezworkflow_process_s
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;







CREATE TABLE ezapprove_items (
    collaboration_id integer DEFAULT 0 NOT NULL,
    id integer DEFAULT nextval('ezapprove_items_s'::text) NOT NULL,
    workflow_process_id integer DEFAULT 0 NOT NULL
);







CREATE TABLE ezbasket (
    id integer DEFAULT nextval('ezbasket_s'::text) NOT NULL,
    order_id integer DEFAULT 0 NOT NULL,
    productcollection_id integer DEFAULT 0 NOT NULL,
    session_id character varying(255) DEFAULT ''::character varying NOT NULL
);







CREATE TABLE ezbinaryfile (
    contentobject_attribute_id integer DEFAULT 0 NOT NULL,
    download_count integer DEFAULT 0 NOT NULL,
    filename character varying(255) DEFAULT ''::character varying NOT NULL,
    mime_type character varying(50) DEFAULT ''::character varying NOT NULL,
    original_filename character varying(255) DEFAULT ''::character varying NOT NULL,
    "version" integer DEFAULT 0 NOT NULL
);







CREATE TABLE ezcollab_group (
    created integer DEFAULT 0 NOT NULL,
    depth integer DEFAULT 0 NOT NULL,
    id integer DEFAULT nextval('ezcollab_group_s'::text) NOT NULL,
    is_open integer DEFAULT 1 NOT NULL,
    modified integer DEFAULT 0 NOT NULL,
    parent_group_id integer DEFAULT 0 NOT NULL,
    path_string character varying(255) DEFAULT ''::character varying NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    title character varying(255) DEFAULT ''::character varying NOT NULL,
    user_id integer DEFAULT 0 NOT NULL
);







CREATE TABLE ezcollab_item (
    created integer DEFAULT 0 NOT NULL,
    creator_id integer DEFAULT 0 NOT NULL,
    data_float1 double precision DEFAULT 0::double precision NOT NULL,
    data_float2 double precision DEFAULT 0::double precision NOT NULL,
    data_float3 double precision DEFAULT 0::double precision NOT NULL,
    data_int1 integer DEFAULT 0 NOT NULL,
    data_int2 integer DEFAULT 0 NOT NULL,
    data_int3 integer DEFAULT 0 NOT NULL,
    data_text1 text NOT NULL,
    data_text2 text NOT NULL,
    data_text3 text NOT NULL,
    id integer DEFAULT nextval('ezcollab_item_s'::text) NOT NULL,
    modified integer DEFAULT 0 NOT NULL,
    status integer DEFAULT 1 NOT NULL,
    type_identifier character varying(40) DEFAULT ''::character varying NOT NULL
);







CREATE TABLE ezcollab_item_group_link (
    collaboration_id integer DEFAULT 0 NOT NULL,
    created integer DEFAULT 0 NOT NULL,
    group_id integer DEFAULT 0 NOT NULL,
    is_active integer DEFAULT 1 NOT NULL,
    is_read integer DEFAULT 0 NOT NULL,
    last_read integer DEFAULT 0 NOT NULL,
    modified integer DEFAULT 0 NOT NULL,
    user_id integer DEFAULT 0 NOT NULL
);







CREATE TABLE ezcollab_item_message_link (
    collaboration_id integer DEFAULT 0 NOT NULL,
    created integer DEFAULT 0 NOT NULL,
    id integer DEFAULT nextval('ezcollab_item_message_link_s'::text) NOT NULL,
    message_id integer DEFAULT 0 NOT NULL,
    message_type integer DEFAULT 0 NOT NULL,
    modified integer DEFAULT 0 NOT NULL,
    participant_id integer DEFAULT 0 NOT NULL
);







CREATE TABLE ezcollab_item_participant_link (
    collaboration_id integer DEFAULT 0 NOT NULL,
    created integer DEFAULT 0 NOT NULL,
    is_active integer DEFAULT 1 NOT NULL,
    is_read integer DEFAULT 0 NOT NULL,
    last_read integer DEFAULT 0 NOT NULL,
    modified integer DEFAULT 0 NOT NULL,
    participant_id integer DEFAULT 0 NOT NULL,
    participant_role integer DEFAULT 1 NOT NULL,
    participant_type integer DEFAULT 1 NOT NULL
);







CREATE TABLE ezcollab_item_status (
    collaboration_id integer DEFAULT 0 NOT NULL,
    is_active integer DEFAULT 1 NOT NULL,
    is_read integer DEFAULT 0 NOT NULL,
    last_read integer DEFAULT 0 NOT NULL,
    user_id integer DEFAULT 0 NOT NULL
);







CREATE TABLE ezcollab_notification_rule (
    collab_identifier character varying(255) DEFAULT ''::character varying NOT NULL,
    id integer DEFAULT nextval('ezcollab_notification_rule_s'::text) NOT NULL,
    user_id character varying(255) DEFAULT ''::character varying NOT NULL
);







CREATE TABLE ezcollab_profile (
    created integer DEFAULT 0 NOT NULL,
    data_text1 text NOT NULL,
    id integer DEFAULT nextval('ezcollab_profile_s'::text) NOT NULL,
    main_group integer DEFAULT 0 NOT NULL,
    modified integer DEFAULT 0 NOT NULL,
    user_id integer DEFAULT 0 NOT NULL
);







CREATE TABLE ezcollab_simple_message (
    created integer DEFAULT 0 NOT NULL,
    creator_id integer DEFAULT 0 NOT NULL,
    data_float1 double precision DEFAULT 0::double precision NOT NULL,
    data_float2 double precision DEFAULT 0::double precision NOT NULL,
    data_float3 double precision DEFAULT 0::double precision NOT NULL,
    data_int1 integer DEFAULT 0 NOT NULL,
    data_int2 integer DEFAULT 0 NOT NULL,
    data_int3 integer DEFAULT 0 NOT NULL,
    data_text1 text NOT NULL,
    data_text2 text NOT NULL,
    data_text3 text NOT NULL,
    id integer DEFAULT nextval('ezcollab_simple_message_s'::text) NOT NULL,
    message_type character varying(40) DEFAULT ''::character varying NOT NULL,
    modified integer DEFAULT 0 NOT NULL
);







CREATE TABLE ezcontent_language (
    disabled integer DEFAULT 0 NOT NULL,
    id integer DEFAULT 0 NOT NULL,
    locale character varying(20) DEFAULT ''::character varying NOT NULL,
    name character varying(255) DEFAULT ''::character varying NOT NULL
);







CREATE TABLE ezcontentbrowsebookmark (
    id integer DEFAULT nextval('ezcontentbrowsebookmark_s'::text) NOT NULL,
    name character varying(255) DEFAULT ''::character varying NOT NULL,
    node_id integer DEFAULT 0 NOT NULL,
    user_id integer DEFAULT 0 NOT NULL
);







CREATE TABLE ezcontentbrowserecent (
    created integer DEFAULT 0 NOT NULL,
    id integer DEFAULT nextval('ezcontentbrowserecent_s'::text) NOT NULL,
    name character varying(255) DEFAULT ''::character varying NOT NULL,
    node_id integer DEFAULT 0 NOT NULL,
    user_id integer DEFAULT 0 NOT NULL
);







CREATE TABLE ezcontentclass (
    always_available integer DEFAULT 0 NOT NULL,
    contentobject_name character varying(255),
    created integer DEFAULT 0 NOT NULL,
    creator_id integer DEFAULT 0 NOT NULL,
    id integer DEFAULT nextval('ezcontentclass_s'::text) NOT NULL,
    identifier character varying(50) DEFAULT ''::character varying NOT NULL,
    initial_language_id integer DEFAULT 0 NOT NULL,
    is_container integer DEFAULT 0 NOT NULL,
    language_mask integer DEFAULT 0 NOT NULL,
    modified integer DEFAULT 0 NOT NULL,
    modifier_id integer DEFAULT 0 NOT NULL,
    remote_id character varying(100) DEFAULT ''::character varying NOT NULL,
    serialized_name_list text,
    sort_field integer DEFAULT 1 NOT NULL,
    sort_order integer DEFAULT 1 NOT NULL,
    url_alias_name character varying(255),
    "version" integer DEFAULT 0 NOT NULL
);







CREATE TABLE ezcontentclass_attribute (
    can_translate integer DEFAULT 1,
    contentclass_id integer DEFAULT 0 NOT NULL,
    data_float1 double precision,
    data_float2 double precision,
    data_float3 double precision,
    data_float4 double precision,
    data_int1 integer,
    data_int2 integer,
    data_int3 integer,
    data_int4 integer,
    data_text1 character varying(50),
    data_text2 character varying(50),
    data_text3 character varying(50),
    data_text4 character varying(255),
    data_text5 text,
    data_type_string character varying(50) DEFAULT ''::character varying NOT NULL,
    id integer DEFAULT nextval('ezcontentclass_attribute_s'::text) NOT NULL,
    identifier character varying(50) DEFAULT ''::character varying NOT NULL,
    is_information_collector integer DEFAULT 0 NOT NULL,
    is_required integer DEFAULT 0 NOT NULL,
    is_searchable integer DEFAULT 0 NOT NULL,
    placement integer DEFAULT 0 NOT NULL,
    serialized_name_list text NOT NULL,
    "version" integer DEFAULT 0 NOT NULL
);







CREATE TABLE ezcontentclass_classgroup (
    contentclass_id integer DEFAULT 0 NOT NULL,
    contentclass_version integer DEFAULT 0 NOT NULL,
    group_id integer DEFAULT 0 NOT NULL,
    group_name character varying(255)
);







CREATE TABLE ezcontentclass_name (
    contentclass_id integer DEFAULT 0 NOT NULL,
    contentclass_version integer DEFAULT 0 NOT NULL,
    language_id integer DEFAULT 0 NOT NULL,
    language_locale character varying(20) DEFAULT ''::character varying NOT NULL,
    name character varying(255) DEFAULT ''::character varying NOT NULL
);







CREATE TABLE ezcontentclassgroup (
    created integer DEFAULT 0 NOT NULL,
    creator_id integer DEFAULT 0 NOT NULL,
    id integer DEFAULT nextval('ezcontentclassgroup_s'::text) NOT NULL,
    modified integer DEFAULT 0 NOT NULL,
    modifier_id integer DEFAULT 0 NOT NULL,
    name character varying(255)
);







CREATE TABLE ezcontentobject (
    contentclass_id integer DEFAULT 0 NOT NULL,
    current_version integer,
    id integer DEFAULT nextval('ezcontentobject_s'::text) NOT NULL,
    initial_language_id integer DEFAULT 0 NOT NULL,
    is_published integer,
    language_mask integer DEFAULT 0 NOT NULL,
    modified integer DEFAULT 0 NOT NULL,
    name character varying(255),
    owner_id integer DEFAULT 0 NOT NULL,
    published integer DEFAULT 0 NOT NULL,
    remote_id character varying(100),
    section_id integer DEFAULT 0 NOT NULL,
    status integer DEFAULT 0
);







CREATE TABLE ezcontentobject_attribute (
    attribute_original_id integer DEFAULT 0,
    contentclassattribute_id integer DEFAULT 0 NOT NULL,
    contentobject_id integer DEFAULT 0 NOT NULL,
    data_float double precision,
    data_int integer,
    data_text text,
    data_type_string character varying(50) DEFAULT ''::character varying,
    id integer DEFAULT nextval('ezcontentobject_attribute_s'::text) NOT NULL,
    language_code character varying(20) DEFAULT ''::character varying NOT NULL,
    language_id integer DEFAULT 0 NOT NULL,
    sort_key_int integer DEFAULT 0 NOT NULL,
    sort_key_string character varying(255) DEFAULT ''::character varying NOT NULL,
    "version" integer DEFAULT 0 NOT NULL
);







CREATE TABLE ezcontentobject_link (
    contentclassattribute_id integer DEFAULT 0 NOT NULL,
    from_contentobject_id integer DEFAULT 0 NOT NULL,
    from_contentobject_version integer DEFAULT 0 NOT NULL,
    id integer DEFAULT nextval('ezcontentobject_link_s'::text) NOT NULL,
    op_code integer DEFAULT 0 NOT NULL,
    relation_type integer DEFAULT 1 NOT NULL,
    to_contentobject_id integer DEFAULT 0 NOT NULL
);







CREATE TABLE ezcontentobject_name (
    content_translation character varying(20) DEFAULT ''::character varying NOT NULL,
    content_version integer DEFAULT 0 NOT NULL,
    contentobject_id integer DEFAULT 0 NOT NULL,
    language_id integer DEFAULT 0 NOT NULL,
    name character varying(255),
    real_translation character varying(20)
);







CREATE TABLE ezcontentobject_trash (
    contentobject_id integer,
    contentobject_version integer,
    depth integer DEFAULT 0 NOT NULL,
    is_hidden integer DEFAULT 0 NOT NULL,
    is_invisible integer DEFAULT 0 NOT NULL,
    main_node_id integer,
    modified_subnode integer DEFAULT 0,
    node_id integer DEFAULT 0 NOT NULL,
    parent_node_id integer DEFAULT 0 NOT NULL,
    path_identification_string text,
    path_string character varying(255) DEFAULT ''::character varying NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    remote_id character varying(100) DEFAULT ''::character varying NOT NULL,
    sort_field integer DEFAULT 1,
    sort_order integer DEFAULT 1
);







CREATE TABLE ezcontentobject_tree (
    contentobject_id integer,
    contentobject_is_published integer,
    contentobject_version integer,
    depth integer DEFAULT 0 NOT NULL,
    is_hidden integer DEFAULT 0 NOT NULL,
    is_invisible integer DEFAULT 0 NOT NULL,
    main_node_id integer,
    modified_subnode integer DEFAULT 0,
    node_id integer DEFAULT nextval('ezcontentobject_tree_s'::text) NOT NULL,
    parent_node_id integer DEFAULT 0 NOT NULL,
    path_identification_string text,
    path_string character varying(255) DEFAULT ''::character varying NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    remote_id character varying(100) DEFAULT ''::character varying NOT NULL,
    sort_field integer DEFAULT 1,
    sort_order integer DEFAULT 1
);







CREATE TABLE ezcontentobject_version (
    contentobject_id integer,
    created integer DEFAULT 0 NOT NULL,
    creator_id integer DEFAULT 0 NOT NULL,
    id integer DEFAULT nextval('ezcontentobject_version_s'::text) NOT NULL,
    initial_language_id integer DEFAULT 0 NOT NULL,
    language_mask integer DEFAULT 0 NOT NULL,
    modified integer DEFAULT 0 NOT NULL,
    status integer DEFAULT 0 NOT NULL,
    user_id integer DEFAULT 0 NOT NULL,
    "version" integer DEFAULT 0 NOT NULL,
    workflow_event_pos integer DEFAULT 0
);







CREATE TABLE ezcurrencydata (
    auto_rate_value numeric(10,5) DEFAULT '0.00000' NOT NULL,
    code character varying(4) DEFAULT ''::character varying NOT NULL,
    custom_rate_value numeric(10,5) DEFAULT '0.00000' NOT NULL,
    id integer DEFAULT nextval('ezcurrencydata_s'::text) NOT NULL,
    locale character varying(255) DEFAULT ''::character varying NOT NULL,
    rate_factor numeric(10,5) DEFAULT '1.00000' NOT NULL,
    status integer DEFAULT 1 NOT NULL,
    symbol character varying(255) DEFAULT ''::character varying NOT NULL
);







CREATE TABLE ezdiscountrule (
    id integer DEFAULT nextval('ezdiscountrule_s'::text) NOT NULL,
    name character varying(255) DEFAULT ''::character varying NOT NULL
);







CREATE TABLE ezdiscountsubrule (
    discount_percent double precision,
    discountrule_id integer DEFAULT 0 NOT NULL,
    id integer DEFAULT nextval('ezdiscountsubrule_s'::text) NOT NULL,
    limitation character(1),
    name character varying(255) DEFAULT ''::character varying NOT NULL
);







CREATE TABLE ezdiscountsubrule_value (
    discountsubrule_id integer DEFAULT 0 NOT NULL,
    issection integer DEFAULT 0 NOT NULL,
    value integer DEFAULT 0 NOT NULL
);







CREATE TABLE ezenumobjectvalue (
    contentobject_attribute_id integer DEFAULT 0 NOT NULL,
    contentobject_attribute_version integer DEFAULT 0 NOT NULL,
    enumelement character varying(255) DEFAULT ''::character varying NOT NULL,
    enumid integer DEFAULT 0 NOT NULL,
    enumvalue character varying(255) DEFAULT ''::character varying NOT NULL
);







CREATE TABLE ezenumvalue (
    contentclass_attribute_id integer DEFAULT 0 NOT NULL,
    contentclass_attribute_version integer DEFAULT 0 NOT NULL,
    enumelement character varying(255) DEFAULT ''::character varying NOT NULL,
    enumvalue character varying(255) DEFAULT ''::character varying NOT NULL,
    id integer DEFAULT nextval('ezenumvalue_s'::text) NOT NULL,
    placement integer DEFAULT 0 NOT NULL
);







CREATE TABLE ezforgot_password (
    hash_key character varying(32) DEFAULT ''::character varying NOT NULL,
    id integer DEFAULT nextval('ezforgot_password_s'::text) NOT NULL,
    "time" integer DEFAULT 0 NOT NULL,
    user_id integer DEFAULT 0 NOT NULL
);







CREATE TABLE ezgeneral_digest_user_settings (
    address character varying(255) DEFAULT ''::character varying NOT NULL,
    "day" character varying(255) DEFAULT ''::character varying NOT NULL,
    digest_type integer DEFAULT 0 NOT NULL,
    id integer DEFAULT nextval('ezgeneral_digest_user_settings_s'::text) NOT NULL,
    receive_digest integer DEFAULT 0 NOT NULL,
    "time" character varying(255) DEFAULT ''::character varying NOT NULL
);







CREATE TABLE ezimage (
    alternative_text character varying(255) DEFAULT ''::character varying NOT NULL,
    contentobject_attribute_id integer DEFAULT 0 NOT NULL,
    filename character varying(255) DEFAULT ''::character varying NOT NULL,
    mime_type character varying(50) DEFAULT ''::character varying NOT NULL,
    original_filename character varying(255) DEFAULT ''::character varying NOT NULL,
    "version" integer DEFAULT 0 NOT NULL
);







CREATE TABLE ezimagefile (
    contentobject_attribute_id integer DEFAULT 0 NOT NULL,
    filepath text NOT NULL,
    id integer DEFAULT nextval('ezimagefile_s'::text) NOT NULL
);







CREATE TABLE ezimagevariation (
    additional_path character varying(255),
    contentobject_attribute_id integer DEFAULT 0 NOT NULL,
    filename character varying(255) DEFAULT ''::character varying NOT NULL,
    height integer DEFAULT 0 NOT NULL,
    requested_height integer DEFAULT 0 NOT NULL,
    requested_width integer DEFAULT 0 NOT NULL,
    "version" integer DEFAULT 0 NOT NULL,
    width integer DEFAULT 0 NOT NULL
);







CREATE TABLE ezinfocollection (
    contentobject_id integer DEFAULT 0 NOT NULL,
    created integer DEFAULT 0 NOT NULL,
    creator_id integer DEFAULT 0 NOT NULL,
    id integer DEFAULT nextval('ezinfocollection_s'::text) NOT NULL,
    modified integer DEFAULT 0,
    user_identifier character varying(34)
);







CREATE TABLE ezinfocollection_attribute (
    contentclass_attribute_id integer DEFAULT 0 NOT NULL,
    contentobject_attribute_id integer,
    contentobject_id integer,
    data_float double precision,
    data_int integer,
    data_text text,
    id integer DEFAULT nextval('ezinfocollection_attribute_s'::text) NOT NULL,
    informationcollection_id integer DEFAULT 0 NOT NULL
);







CREATE TABLE ezisbn_group (
    description character varying(255) DEFAULT ''::character varying NOT NULL,
    group_number integer DEFAULT 0 NOT NULL,
    id integer DEFAULT nextval('ezisbn_group_s'::text) NOT NULL
);







CREATE TABLE ezisbn_group_range (
    from_number integer DEFAULT 0 NOT NULL,
    group_from character varying(32) DEFAULT ''::character varying NOT NULL,
    group_length integer DEFAULT 0 NOT NULL,
    group_to character varying(32) DEFAULT ''::character varying NOT NULL,
    id integer DEFAULT nextval('ezisbn_group_range_s'::text) NOT NULL,
    to_number integer DEFAULT 0 NOT NULL
);







CREATE TABLE ezisbn_registrant_range (
    from_number integer DEFAULT 0 NOT NULL,
    id integer DEFAULT nextval('ezisbn_registrant_range_s'::text) NOT NULL,
    isbn_group_id integer DEFAULT 0 NOT NULL,
    registrant_from character varying(32) DEFAULT ''::character varying NOT NULL,
    registrant_length integer DEFAULT 0 NOT NULL,
    registrant_to character varying(32) DEFAULT ''::character varying NOT NULL,
    to_number integer DEFAULT 0 NOT NULL
);







CREATE TABLE ezkeyword (
    class_id integer DEFAULT 0 NOT NULL,
    id integer DEFAULT nextval('ezkeyword_s'::text) NOT NULL,
    keyword character varying(255)
);







CREATE TABLE ezkeyword_attribute_link (
    id integer DEFAULT nextval('ezkeyword_attribute_link_s'::text) NOT NULL,
    keyword_id integer DEFAULT 0 NOT NULL,
    objectattribute_id integer DEFAULT 0 NOT NULL
);







CREATE TABLE ezmedia (
    contentobject_attribute_id integer DEFAULT 0 NOT NULL,
    controls character varying(50),
    filename character varying(255) DEFAULT ''::character varying NOT NULL,
    has_controller integer DEFAULT 0,
    height integer,
    is_autoplay integer DEFAULT 0,
    is_loop integer DEFAULT 0,
    mime_type character varying(50) DEFAULT ''::character varying NOT NULL,
    original_filename character varying(255) DEFAULT ''::character varying NOT NULL,
    pluginspage character varying(255),
    quality character varying(50),
    "version" integer DEFAULT 0 NOT NULL,
    width integer
);







CREATE TABLE ezmessage (
    body text,
    destination_address character varying(50) DEFAULT ''::character varying NOT NULL,
    id integer DEFAULT nextval('ezmessage_s'::text) NOT NULL,
    is_sent integer DEFAULT 0 NOT NULL,
    send_method character varying(50) DEFAULT ''::character varying NOT NULL,
    send_time character varying(50) DEFAULT ''::character varying NOT NULL,
    send_weekday character varying(50) DEFAULT ''::character varying NOT NULL,
    title character varying(255) DEFAULT ''::character varying NOT NULL
);







CREATE TABLE ezmodule_run (
    function_name character varying(255),
    id integer DEFAULT nextval('ezmodule_run_s'::text) NOT NULL,
    module_data text,
    module_name character varying(255),
    workflow_process_id integer
);







CREATE TABLE ezmultipricedata (
    contentobject_attr_id integer DEFAULT 0 NOT NULL,
    contentobject_attr_version integer DEFAULT 0 NOT NULL,
    currency_code character varying(4) DEFAULT ''::character varying NOT NULL,
    id integer DEFAULT nextval('ezmultipricedata_s'::text) NOT NULL,
    "type" integer DEFAULT 0 NOT NULL,
    value numeric(15,2) DEFAULT '0.00' NOT NULL
);







CREATE TABLE eznode_assignment (
    contentobject_id integer,
    contentobject_version integer,
    from_node_id integer DEFAULT 0,
    id integer DEFAULT nextval('eznode_assignment_s'::text) NOT NULL,
    is_main integer DEFAULT 0 NOT NULL,
    op_code integer DEFAULT 0 NOT NULL,
    parent_node integer,
    parent_remote_id character varying(100) DEFAULT ''::character varying NOT NULL,
    remote_id integer DEFAULT 0 NOT NULL,
    sort_field integer DEFAULT 1,
    sort_order integer DEFAULT 1
);







CREATE TABLE eznotificationcollection (
    data_subject text NOT NULL,
    data_text text NOT NULL,
    event_id integer DEFAULT 0 NOT NULL,
    "handler" character varying(255) DEFAULT ''::character varying NOT NULL,
    id integer DEFAULT nextval('eznotificationcollection_s'::text) NOT NULL,
    transport character varying(255) DEFAULT ''::character varying NOT NULL
);







CREATE TABLE eznotificationcollection_item (
    address character varying(255) DEFAULT ''::character varying NOT NULL,
    collection_id integer DEFAULT 0 NOT NULL,
    event_id integer DEFAULT 0 NOT NULL,
    id integer DEFAULT nextval('eznotificationcollection_item_s'::text) NOT NULL,
    send_date integer DEFAULT 0 NOT NULL
);







CREATE TABLE eznotificationevent (
    data_int1 integer DEFAULT 0 NOT NULL,
    data_int2 integer DEFAULT 0 NOT NULL,
    data_int3 integer DEFAULT 0 NOT NULL,
    data_int4 integer DEFAULT 0 NOT NULL,
    data_text1 text NOT NULL,
    data_text2 text NOT NULL,
    data_text3 text NOT NULL,
    data_text4 text NOT NULL,
    event_type_string character varying(255) DEFAULT ''::character varying NOT NULL,
    id integer DEFAULT nextval('eznotificationevent_s'::text) NOT NULL,
    status integer DEFAULT 0 NOT NULL
);







CREATE TABLE ezoperation_memento (
    id integer DEFAULT nextval('ezoperation_memento_s'::text) NOT NULL,
    main integer DEFAULT 0 NOT NULL,
    main_key character varying(32) DEFAULT ''::character varying NOT NULL,
    memento_data text NOT NULL,
    memento_key character varying(32) DEFAULT ''::character varying NOT NULL
);







CREATE TABLE ezorder (
    account_identifier character varying(100) DEFAULT 'default'::character varying NOT NULL,
    created integer DEFAULT 0 NOT NULL,
    data_text_1 text,
    data_text_2 text,
    email character varying(150) DEFAULT ''::character varying,
    id integer DEFAULT nextval('ezorder_s'::text) NOT NULL,
    ignore_vat integer DEFAULT 0 NOT NULL,
    is_archived integer DEFAULT 0 NOT NULL,
    is_temporary integer DEFAULT 1 NOT NULL,
    order_nr integer DEFAULT 0 NOT NULL,
    productcollection_id integer DEFAULT 0 NOT NULL,
    status_id integer DEFAULT 0,
    status_modified integer DEFAULT 0,
    status_modifier_id integer DEFAULT 0,
    user_id integer DEFAULT 0 NOT NULL
);







CREATE TABLE ezorder_item (
    description character varying(255),
    id integer DEFAULT nextval('ezorder_item_s'::text) NOT NULL,
    is_vat_inc integer DEFAULT 0 NOT NULL,
    order_id integer DEFAULT 0 NOT NULL,
    price double precision,
    "type" character varying(30),
    vat_value integer DEFAULT 0 NOT NULL
);







CREATE TABLE ezorder_status (
    id integer DEFAULT nextval('ezorder_status_s'::text) NOT NULL,
    is_active integer DEFAULT 1 NOT NULL,
    name character varying(255) DEFAULT ''::character varying NOT NULL,
    status_id integer DEFAULT 0 NOT NULL
);







CREATE TABLE ezorder_status_history (
    id integer DEFAULT nextval('ezorder_status_history_s'::text) NOT NULL,
    modified integer DEFAULT 0 NOT NULL,
    modifier_id integer DEFAULT 0 NOT NULL,
    order_id integer DEFAULT 0 NOT NULL,
    status_id integer DEFAULT 0 NOT NULL
);







CREATE TABLE ezpackage (
    id integer DEFAULT nextval('ezpackage_s'::text) NOT NULL,
    install_date integer DEFAULT 0 NOT NULL,
    name character varying(100) DEFAULT ''::character varying NOT NULL,
    "version" character varying(30) DEFAULT '0'::character varying NOT NULL
);







CREATE TABLE ezpaymentobject (
    id integer DEFAULT nextval('ezpaymentobject_s'::text) NOT NULL,
    order_id integer DEFAULT 0 NOT NULL,
    payment_string character varying(255) DEFAULT ''::character varying NOT NULL,
    status integer DEFAULT 0 NOT NULL,
    workflowprocess_id integer DEFAULT 0 NOT NULL
);







CREATE TABLE ezpdf_export (
    created integer,
    creator_id integer,
    export_classes character varying(255),
    export_structure character varying(255),
    id integer DEFAULT nextval('ezpdf_export_s'::text) NOT NULL,
    intro_text text,
    modified integer,
    modifier_id integer,
    pdf_filename character varying(255),
    show_frontpage integer,
    site_access character varying(255),
    source_node_id integer,
    status integer,
    sub_text text,
    title character varying(255),
    "version" integer DEFAULT 0 NOT NULL
);







CREATE TABLE ezpending_actions (
    "action" character varying(64) DEFAULT ''::character varying NOT NULL,
    param text
);







CREATE TABLE ezpolicy (
    function_name character varying(255),
    id integer DEFAULT nextval('ezpolicy_s'::text) NOT NULL,
    module_name character varying(255),
    role_id integer
);







CREATE TABLE ezpolicy_limitation (
    id integer DEFAULT nextval('ezpolicy_limitation_s'::text) NOT NULL,
    identifier character varying(255) DEFAULT ''::character varying NOT NULL,
    policy_id integer
);







CREATE TABLE ezpolicy_limitation_value (
    id integer DEFAULT nextval('ezpolicy_limitation_value_s'::text) NOT NULL,
    limitation_id integer,
    value character varying(255)
);







CREATE TABLE ezpreferences (
    id integer DEFAULT nextval('ezpreferences_s'::text) NOT NULL,
    name character varying(100),
    user_id integer DEFAULT 0 NOT NULL,
    value character varying(100)
);







CREATE TABLE ezproductcategory (
    id integer DEFAULT nextval('ezproductcategory_s'::text) NOT NULL,
    name character varying(255) DEFAULT ''::character varying NOT NULL
);







CREATE TABLE ezproductcollection (
    created integer,
    currency_code character varying(4) DEFAULT ''::character varying NOT NULL,
    id integer DEFAULT nextval('ezproductcollection_s'::text) NOT NULL
);







CREATE TABLE ezproductcollection_item (
    contentobject_id integer DEFAULT 0 NOT NULL,
    discount double precision,
    id integer DEFAULT nextval('ezproductcollection_item_s'::text) NOT NULL,
    is_vat_inc integer,
    item_count integer DEFAULT 0 NOT NULL,
    name character varying(255) DEFAULT ''::character varying NOT NULL,
    price double precision DEFAULT 0::double precision,
    productcollection_id integer DEFAULT 0 NOT NULL,
    vat_value double precision
);







CREATE TABLE ezproductcollection_item_opt (
    id integer DEFAULT nextval('ezproductcollection_item_opt_s'::text) NOT NULL,
    item_id integer DEFAULT 0 NOT NULL,
    name character varying(255) DEFAULT ''::character varying NOT NULL,
    object_attribute_id integer,
    option_item_id integer DEFAULT 0 NOT NULL,
    price double precision DEFAULT 0::double precision NOT NULL,
    value character varying(255) DEFAULT ''::character varying NOT NULL
);







CREATE TABLE ezrole (
    id integer DEFAULT nextval('ezrole_s'::text) NOT NULL,
    is_new integer DEFAULT 0 NOT NULL,
    name character varying(255) DEFAULT ''::character varying NOT NULL,
    value character(1),
    "version" integer DEFAULT 0
);







CREATE TABLE ezrss_export (
    access_url character varying(255),
    active integer,
    created integer,
    creator_id integer,
    description text,
    id integer DEFAULT nextval('ezrss_export_s'::text) NOT NULL,
    image_id integer,
    main_node_only integer DEFAULT 1 NOT NULL,
    modified integer,
    modifier_id integer,
    number_of_objects integer DEFAULT 0 NOT NULL,
    rss_version character varying(255),
    site_access character varying(255),
    status integer DEFAULT 0 NOT NULL,
    title character varying(255),
    url character varying(255)
);







CREATE TABLE ezrss_export_item (
    class_id integer,
    description character varying(255),
    id integer DEFAULT nextval('ezrss_export_item_s'::text) NOT NULL,
    rssexport_id integer,
    source_node_id integer,
    status integer DEFAULT 0 NOT NULL,
    subnodes integer DEFAULT 0 NOT NULL,
    title character varying(255)
);







CREATE TABLE ezrss_import (
    active integer,
    class_description character varying(255),
    class_id integer,
    class_title character varying(255),
    class_url character varying(255),
    created integer,
    creator_id integer,
    destination_node_id integer,
    id integer DEFAULT nextval('ezrss_import_s'::text) NOT NULL,
    import_description text NOT NULL,
    modified integer,
    modifier_id integer,
    name character varying(255),
    object_owner_id integer,
    status integer DEFAULT 0 NOT NULL,
    url text
);







CREATE TABLE ezsearch_object_word_link (
    contentclass_attribute_id integer DEFAULT 0 NOT NULL,
    contentclass_id integer DEFAULT 0 NOT NULL,
    contentobject_id integer DEFAULT 0 NOT NULL,
    frequency double precision DEFAULT 0::double precision NOT NULL,
    id integer DEFAULT nextval('ezsearch_object_word_link_s'::text) NOT NULL,
    identifier character varying(255) DEFAULT ''::character varying NOT NULL,
    integer_value integer DEFAULT 0 NOT NULL,
    next_word_id integer DEFAULT 0 NOT NULL,
    placement integer DEFAULT 0 NOT NULL,
    prev_word_id integer DEFAULT 0 NOT NULL,
    published integer DEFAULT 0 NOT NULL,
    section_id integer DEFAULT 0 NOT NULL,
    word_id integer DEFAULT 0 NOT NULL
);







CREATE TABLE ezsearch_return_count (
    count integer DEFAULT 0 NOT NULL,
    id integer DEFAULT nextval('ezsearch_return_count_s'::text) NOT NULL,
    phrase_id integer DEFAULT 0 NOT NULL,
    "time" integer DEFAULT 0 NOT NULL
);







CREATE TABLE ezsearch_search_phrase (
    id integer DEFAULT nextval('ezsearch_search_phrase_s'::text) NOT NULL,
    phrase character varying(250),
    phrase_count integer DEFAULT 0,
    result_count integer DEFAULT 0
);







CREATE TABLE ezsearch_word (
    id integer DEFAULT nextval('ezsearch_word_s'::text) NOT NULL,
    object_count integer DEFAULT 0 NOT NULL,
    word character varying(150)
);







CREATE TABLE ezsection (
    id integer DEFAULT nextval('ezsection_s'::text) NOT NULL,
    locale character varying(255),
    name character varying(255),
    navigation_part_identifier character varying(100) DEFAULT 'ezcontentnavigationpart'::character varying
);







CREATE TABLE ezsession (
    data text NOT NULL,
    expiration_time integer DEFAULT 0 NOT NULL,
    session_key character varying(32) DEFAULT ''::character varying NOT NULL,
    user_id integer DEFAULT 0 NOT NULL
);







CREATE TABLE ezsite_data (
    name character varying(60) DEFAULT ''::character varying NOT NULL,
    value text NOT NULL
);







CREATE TABLE ezsubtree_notification_rule (
    id integer DEFAULT nextval('ezsubtree_notification_rule_s'::text) NOT NULL,
    node_id integer DEFAULT 0 NOT NULL,
    use_digest integer DEFAULT 0,
    user_id integer DEFAULT 0 NOT NULL
);







CREATE TABLE eztipafriend_counter (
    count integer DEFAULT 0 NOT NULL,
    node_id integer DEFAULT 0 NOT NULL,
    requested integer DEFAULT 0 NOT NULL
);







CREATE TABLE eztipafriend_request (
    created integer DEFAULT 0 NOT NULL,
    email_receiver character varying(100) DEFAULT ''::character varying NOT NULL
);







CREATE TABLE eztrigger (
    connect_type character(1) DEFAULT ''::bpchar NOT NULL,
    function_name character varying(200) DEFAULT ''::character varying NOT NULL,
    id integer DEFAULT nextval('eztrigger_s'::text) NOT NULL,
    module_name character varying(200) DEFAULT ''::character varying NOT NULL,
    name character varying(255),
    workflow_id integer
);







CREATE TABLE ezurl (
    created integer DEFAULT 0 NOT NULL,
    id integer DEFAULT nextval('ezurl_s'::text) NOT NULL,
    is_valid integer DEFAULT 1 NOT NULL,
    last_checked integer DEFAULT 0 NOT NULL,
    modified integer DEFAULT 0 NOT NULL,
    original_url_md5 character varying(32) DEFAULT ''::character varying NOT NULL,
    url text
);







CREATE TABLE ezurl_object_link (
    contentobject_attribute_id integer DEFAULT 0 NOT NULL,
    contentobject_attribute_version integer DEFAULT 0 NOT NULL,
    url_id integer DEFAULT 0 NOT NULL
);







CREATE TABLE ezurlalias (
    destination_url text NOT NULL,
    forward_to_id integer DEFAULT 0 NOT NULL,
    id integer DEFAULT nextval('ezurlalias_s'::text) NOT NULL,
    is_imported integer DEFAULT 0 NOT NULL,
    is_internal integer DEFAULT 1 NOT NULL,
    is_wildcard integer DEFAULT 0 NOT NULL,
    source_md5 character varying(32),
    source_url text NOT NULL
);







CREATE TABLE ezurlalias_ml (
    "action" text NOT NULL,
    action_type character varying(32) DEFAULT ''::character varying NOT NULL,
    alias_redirects integer DEFAULT 1 NOT NULL,
    id integer DEFAULT 0 NOT NULL,
    is_alias integer DEFAULT 0 NOT NULL,
    is_original integer DEFAULT 0 NOT NULL,
    lang_mask integer DEFAULT 0 NOT NULL,
    link integer DEFAULT 0 NOT NULL,
    parent integer DEFAULT 0 NOT NULL,
    text text NOT NULL,
    text_md5 character varying(32) DEFAULT ''::character varying NOT NULL
);







CREATE TABLE ezurlwildcard (
    destination_url text NOT NULL,
    id integer DEFAULT nextval('ezurlwildcard_s'::text) NOT NULL,
    source_url text NOT NULL,
    "type" integer DEFAULT 0 NOT NULL
);







CREATE TABLE ezuser (
    contentobject_id integer DEFAULT 0 NOT NULL,
    email character varying(150) DEFAULT ''::character varying NOT NULL,
    login character varying(150) DEFAULT ''::character varying NOT NULL,
    password_hash character varying(50),
    password_hash_type integer DEFAULT 1 NOT NULL
);







CREATE TABLE ezuser_accountkey (
    hash_key character varying(32) DEFAULT ''::character varying NOT NULL,
    id integer DEFAULT nextval('ezuser_accountkey_s'::text) NOT NULL,
    "time" integer DEFAULT 0 NOT NULL,
    user_id integer DEFAULT 0 NOT NULL
);







CREATE TABLE ezuser_discountrule (
    contentobject_id integer,
    discountrule_id integer,
    id integer DEFAULT nextval('ezuser_discountrule_s'::text) NOT NULL,
    name character varying(255) DEFAULT ''::character varying NOT NULL
);







CREATE TABLE ezuser_role (
    contentobject_id integer,
    id integer DEFAULT nextval('ezuser_role_s'::text) NOT NULL,
    limit_identifier character varying(255) DEFAULT ''::character varying,
    limit_value character varying(255) DEFAULT ''::character varying,
    role_id integer
);







CREATE TABLE ezuser_setting (
    is_enabled integer DEFAULT 0 NOT NULL,
    max_login integer,
    user_id integer DEFAULT 0 NOT NULL
);







CREATE TABLE ezuservisit (
    current_visit_timestamp integer DEFAULT 0 NOT NULL,
    failed_login_attempts integer DEFAULT 0 NOT NULL,
    last_visit_timestamp integer DEFAULT 0 NOT NULL,
    user_id integer DEFAULT 0 NOT NULL
);







CREATE TABLE ezvatrule (
    country_code character varying(255) DEFAULT ''::character varying NOT NULL,
    id integer DEFAULT nextval('ezvatrule_s'::text) NOT NULL,
    vat_type integer DEFAULT 0 NOT NULL
);







CREATE TABLE ezvatrule_product_category (
    product_category_id integer DEFAULT 0 NOT NULL,
    vatrule_id integer DEFAULT 0 NOT NULL
);







CREATE TABLE ezvattype (
    id integer DEFAULT nextval('ezvattype_s'::text) NOT NULL,
    name character varying(255) DEFAULT ''::character varying NOT NULL,
    percentage double precision
);







CREATE TABLE ezview_counter (
    count integer DEFAULT 0 NOT NULL,
    node_id integer DEFAULT 0 NOT NULL
);







CREATE TABLE ezwaituntildatevalue (
    contentclass_attribute_id integer DEFAULT 0 NOT NULL,
    contentclass_id integer DEFAULT 0 NOT NULL,
    id integer DEFAULT nextval('ezwaituntildatevalue_s'::text) NOT NULL,
    workflow_event_id integer DEFAULT 0 NOT NULL,
    workflow_event_version integer DEFAULT 0 NOT NULL
);







CREATE TABLE ezwishlist (
    id integer DEFAULT nextval('ezwishlist_s'::text) NOT NULL,
    productcollection_id integer DEFAULT 0 NOT NULL,
    user_id integer DEFAULT 0 NOT NULL
);







CREATE TABLE ezworkflow (
    created integer DEFAULT 0 NOT NULL,
    creator_id integer DEFAULT 0 NOT NULL,
    id integer DEFAULT nextval('ezworkflow_s'::text) NOT NULL,
    is_enabled integer DEFAULT 0 NOT NULL,
    modified integer DEFAULT 0 NOT NULL,
    modifier_id integer DEFAULT 0 NOT NULL,
    name character varying(255) DEFAULT ''::character varying NOT NULL,
    "version" integer DEFAULT 0 NOT NULL,
    workflow_type_string character varying(50) DEFAULT ''::character varying NOT NULL
);







CREATE TABLE ezworkflow_assign (
    access_type integer DEFAULT 0 NOT NULL,
    as_tree integer DEFAULT 0 NOT NULL,
    id integer DEFAULT nextval('ezworkflow_assign_s'::text) NOT NULL,
    node_id integer DEFAULT 0 NOT NULL,
    workflow_id integer DEFAULT 0 NOT NULL
);







CREATE TABLE ezworkflow_event (
    data_int1 integer,
    data_int2 integer,
    data_int3 integer,
    data_int4 integer,
    data_text1 character varying(50),
    data_text2 character varying(50),
    data_text3 character varying(50),
    data_text4 character varying(50),
    description character varying(50) DEFAULT ''::character varying NOT NULL,
    id integer DEFAULT nextval('ezworkflow_event_s'::text) NOT NULL,
    placement integer DEFAULT 0 NOT NULL,
    "version" integer DEFAULT 0 NOT NULL,
    workflow_id integer DEFAULT 0 NOT NULL,
    workflow_type_string character varying(50) DEFAULT ''::character varying NOT NULL
);







CREATE TABLE ezworkflow_group (
    created integer DEFAULT 0 NOT NULL,
    creator_id integer DEFAULT 0 NOT NULL,
    id integer DEFAULT nextval('ezworkflow_group_s'::text) NOT NULL,
    modified integer DEFAULT 0 NOT NULL,
    modifier_id integer DEFAULT 0 NOT NULL,
    name character varying(255) DEFAULT ''::character varying NOT NULL
);







CREATE TABLE ezworkflow_group_link (
    group_id integer DEFAULT 0 NOT NULL,
    group_name character varying(255),
    workflow_id integer DEFAULT 0 NOT NULL,
    workflow_version integer DEFAULT 0 NOT NULL
);







CREATE TABLE ezworkflow_process (
    activation_date integer,
    content_id integer DEFAULT 0 NOT NULL,
    content_version integer DEFAULT 0 NOT NULL,
    created integer DEFAULT 0 NOT NULL,
    event_id integer DEFAULT 0 NOT NULL,
    event_position integer DEFAULT 0 NOT NULL,
    event_state integer,
    event_status integer DEFAULT 0 NOT NULL,
    id integer DEFAULT nextval('ezworkflow_process_s'::text) NOT NULL,
    last_event_id integer DEFAULT 0 NOT NULL,
    last_event_position integer DEFAULT 0 NOT NULL,
    last_event_status integer DEFAULT 0 NOT NULL,
    memento_key character varying(32),
    modified integer DEFAULT 0 NOT NULL,
    node_id integer DEFAULT 0 NOT NULL,
    parameters text,
    process_key character varying(32) DEFAULT ''::character varying NOT NULL,
    session_key character varying(32) DEFAULT '0'::character varying NOT NULL,
    status integer,
    user_id integer DEFAULT 0 NOT NULL,
    workflow_id integer DEFAULT 0 NOT NULL
);







CREATE INDEX ezbasket_session_id ON ezbasket USING btree (session_id);







CREATE INDEX ezcollab_group_depth ON ezcollab_group USING btree (depth);







CREATE INDEX ezcollab_group_path ON ezcollab_group USING btree (path_string);







CREATE INDEX ezcontent_language_name ON ezcontent_language USING btree (name);







CREATE INDEX ezcontentbrowsebookmark_user ON ezcontentbrowsebookmark USING btree (user_id);







CREATE INDEX ezcontentbrowserecent_user ON ezcontentbrowserecent USING btree (user_id);







CREATE INDEX ezcontentclass_version ON ezcontentclass USING btree ("version");







CREATE INDEX ezcontentclass_attr_ccid ON ezcontentclass_attribute USING btree (contentclass_id);







CREATE INDEX ezcontentobject_classid ON ezcontentobject USING btree (contentclass_id);







CREATE INDEX ezcontentobject_currentversion ON ezcontentobject USING btree (current_version);







CREATE INDEX ezcontentobject_lmask ON ezcontentobject USING btree (language_mask);







CREATE INDEX ezcontentobject_owner ON ezcontentobject USING btree (owner_id);







CREATE INDEX ezcontentobject_pub ON ezcontentobject USING btree (published);







CREATE UNIQUE INDEX ezcontentobject_remote_id ON ezcontentobject USING btree (remote_id);







CREATE INDEX ezcontentobject_status ON ezcontentobject USING btree (status);







CREATE INDEX ezcontentobject_attr_id ON ezcontentobject_attribute USING btree (id);







CREATE INDEX ezcontentobject_attribute_co_id_ver_lang_code ON ezcontentobject_attribute USING btree (contentobject_id, "version", language_code);







CREATE INDEX ezcontentobject_attribute_contentobject_id ON ezcontentobject_attribute USING btree (contentobject_id);







CREATE INDEX ezcontentobject_attribute_language_code ON ezcontentobject_attribute USING btree (language_code);







CREATE INDEX sort_key_int ON ezcontentobject_attribute USING btree (sort_key_int);







CREATE INDEX sort_key_string ON ezcontentobject_attribute USING btree (sort_key_string);







CREATE INDEX ezco_link_from ON ezcontentobject_link USING btree (from_contentobject_id, from_contentobject_version, contentclassattribute_id);







CREATE INDEX ezco_link_to_co_id ON ezcontentobject_link USING btree (to_contentobject_id);







CREATE INDEX ezcontentobject_name_co_id ON ezcontentobject_name USING btree (contentobject_id);







CREATE INDEX ezcontentobject_name_cov_id ON ezcontentobject_name USING btree (content_version);







CREATE INDEX ezcontentobject_name_lang_id ON ezcontentobject_name USING btree (language_id);







CREATE INDEX ezcontentobject_name_name ON ezcontentobject_name USING btree (name);







CREATE INDEX ezcobj_trash_co_id ON ezcontentobject_trash USING btree (contentobject_id);







CREATE INDEX ezcobj_trash_depth ON ezcontentobject_trash USING btree (depth);







CREATE INDEX ezcobj_trash_modified_subnode ON ezcontentobject_trash USING btree (modified_subnode);







CREATE INDEX ezcobj_trash_p_node_id ON ezcontentobject_trash USING btree (parent_node_id);







CREATE INDEX ezcobj_trash_path ON ezcontentobject_trash USING btree (path_string);







CREATE INDEX ezcobj_trash_path_ident ON ezcontentobject_trash USING btree (path_identification_string);







CREATE INDEX ezcontentobject_tree_co_id ON ezcontentobject_tree USING btree (contentobject_id);







CREATE INDEX ezcontentobject_tree_depth ON ezcontentobject_tree USING btree (depth);







CREATE INDEX ezcontentobject_tree_p_node_id ON ezcontentobject_tree USING btree (parent_node_id);







CREATE INDEX ezcontentobject_tree_path ON ezcontentobject_tree USING btree (path_string);







CREATE INDEX ezcontentobject_tree_path_ident ON ezcontentobject_tree USING btree (path_identification_string);







CREATE INDEX modified_subnode ON ezcontentobject_tree USING btree (modified_subnode);







CREATE INDEX ezcobj_version_creator_id ON ezcontentobject_version USING btree (creator_id);







CREATE INDEX ezcobj_version_status ON ezcontentobject_version USING btree (status);







CREATE INDEX idx_object_version_objver ON ezcontentobject_version USING btree (contentobject_id, "version");







CREATE INDEX ezcurrencydata_code ON ezcurrencydata USING btree (code);







CREATE INDEX ezenumobjectvalue_co_attr_id_co_attr_ver ON ezenumobjectvalue USING btree (contentobject_attribute_id, contentobject_attribute_version);







CREATE INDEX ezenumvalue_co_cl_attr_id_co_class_att_ver ON ezenumvalue USING btree (contentclass_attribute_id, contentclass_attribute_version);







CREATE INDEX ezimagefile_coid ON ezimagefile USING btree (contentobject_attribute_id);







CREATE INDEX ezimagefile_file ON ezimagefile USING btree (filepath);







CREATE INDEX ezinfocollection_attr_co_id ON ezinfocollection_attribute USING btree (contentobject_id);







CREATE INDEX ezkeyword_keyword ON ezkeyword USING btree (keyword);







CREATE INDEX ezkeyword_keyword_id ON ezkeyword USING btree (keyword, id);







CREATE INDEX ezkeyword_attr_link_keyword_id ON ezkeyword_attribute_link USING btree (keyword_id);







CREATE INDEX ezkeyword_attr_link_kid_oaid ON ezkeyword_attribute_link USING btree (keyword_id, objectattribute_id);







CREATE UNIQUE INDEX ezmodule_run_workflow_process_id_s ON ezmodule_run USING btree (workflow_process_id);







CREATE INDEX ezmultipricedata_coa_id ON ezmultipricedata USING btree (contentobject_attr_id);







CREATE INDEX ezmultipricedata_coa_version ON ezmultipricedata USING btree (contentobject_attr_version);







CREATE INDEX ezmultipricedata_currency_code ON ezmultipricedata USING btree (currency_code);







CREATE INDEX eznode_assignment_co_id ON eznode_assignment USING btree (contentobject_id);







CREATE INDEX eznode_assignment_co_version ON eznode_assignment USING btree (contentobject_version);







CREATE INDEX eznode_assignment_coid_cov ON eznode_assignment USING btree (contentobject_id, contentobject_version);







CREATE INDEX eznode_assignment_is_main ON eznode_assignment USING btree (is_main);







CREATE INDEX eznode_assignment_parent_node ON eznode_assignment USING btree (parent_node);







CREATE INDEX ezoperation_memento_memento_key_main ON ezoperation_memento USING btree (memento_key, main);







CREATE INDEX ezorder_is_archived ON ezorder USING btree (is_archived);







CREATE INDEX ezorder_is_tmp ON ezorder USING btree (is_temporary);







CREATE INDEX ezorder_item_order_id ON ezorder_item USING btree (order_id);







CREATE INDEX ezorder_item_type ON ezorder_item USING btree ("type");







CREATE INDEX ezorder_status_active ON ezorder_status USING btree (is_active);







CREATE INDEX ezorder_status_name ON ezorder_status USING btree (name);







CREATE INDEX ezorder_status_sid ON ezorder_status USING btree (status_id);







CREATE INDEX ezorder_status_history_mod ON ezorder_status_history USING btree (modified);







CREATE INDEX ezorder_status_history_oid ON ezorder_status_history USING btree (order_id);







CREATE INDEX ezorder_status_history_sid ON ezorder_status_history USING btree (status_id);







CREATE INDEX ezpending_actions_action ON ezpending_actions USING btree ("action");







CREATE INDEX ezpolicy_limitation_value_val ON ezpolicy_limitation_value USING btree (value);







CREATE INDEX ezpreferences_name ON ezpreferences USING btree (name);







CREATE INDEX ezpreferences_user_id_idx ON ezpreferences USING btree (user_id, name);







CREATE INDEX ezproductcollection_item_contentobject_id ON ezproductcollection_item USING btree (contentobject_id);







CREATE INDEX ezproductcollection_item_productcollection_id ON ezproductcollection_item USING btree (productcollection_id);







CREATE INDEX ezproductcollection_item_opt_item_id ON ezproductcollection_item_opt USING btree (item_id);







CREATE INDEX ezrss_export_rsseid ON ezrss_export_item USING btree (rssexport_id);







CREATE INDEX ezsearch_object_word_link_frequency ON ezsearch_object_word_link USING btree (frequency);







CREATE INDEX ezsearch_object_word_link_identifier ON ezsearch_object_word_link USING btree (identifier);







CREATE INDEX ezsearch_object_word_link_integer_value ON ezsearch_object_word_link USING btree (integer_value);







CREATE INDEX ezsearch_object_word_link_object ON ezsearch_object_word_link USING btree (contentobject_id);







CREATE INDEX ezsearch_object_word_link_word ON ezsearch_object_word_link USING btree (word_id);







CREATE INDEX ezsearch_return_cnt_ph_id_cnt ON ezsearch_return_count USING btree (phrase_id, count);







CREATE INDEX ezsearch_search_phrase_count ON ezsearch_search_phrase USING btree (phrase_count);







CREATE UNIQUE INDEX ezsearch_search_phrase_phrase ON ezsearch_search_phrase USING btree (phrase);







CREATE INDEX ezsearch_word_obj_count ON ezsearch_word USING btree (object_count);







CREATE INDEX ezsearch_word_word_i ON ezsearch_word USING btree (word);







CREATE INDEX expiration_time ON ezsession USING btree (expiration_time);







CREATE INDEX ezsession_user_id ON ezsession USING btree (user_id);







CREATE INDEX ezsubtree_notification_rule_user_id ON ezsubtree_notification_rule USING btree (user_id);







CREATE INDEX eztipafriend_request_created ON eztipafriend_request USING btree (created);







CREATE INDEX eztipafriend_request_email_rec ON eztipafriend_request USING btree (email_receiver);







CREATE UNIQUE INDEX eztrigger_def_id ON eztrigger USING btree (module_name, function_name, connect_type);







CREATE INDEX eztrigger_fetch ON eztrigger USING btree (name, module_name, function_name);







CREATE INDEX ezurl_url ON ezurl USING btree (url);







CREATE INDEX ezurl_ol_coa_id ON ezurl_object_link USING btree (contentobject_attribute_id);







CREATE INDEX ezurl_ol_coa_version ON ezurl_object_link USING btree (contentobject_attribute_version);







CREATE INDEX ezurl_ol_url_id ON ezurl_object_link USING btree (url_id);







CREATE INDEX ezurlalias_desturl ON ezurlalias USING btree (destination_url);







CREATE INDEX ezurlalias_forward_to_id ON ezurlalias USING btree (forward_to_id);







CREATE INDEX ezurlalias_imp_wcard_fwd ON ezurlalias USING btree (is_imported, is_wildcard, forward_to_id);







CREATE INDEX ezurlalias_source_md5 ON ezurlalias USING btree (source_md5);







CREATE INDEX ezurlalias_source_url ON ezurlalias USING btree (source_url);







CREATE INDEX ezurlalias_wcard_fwd ON ezurlalias USING btree (is_wildcard, forward_to_id);







CREATE INDEX ezurlalias_ml_act_org ON ezurlalias_ml USING btree ("action", is_original);







CREATE INDEX ezurlalias_ml_action ON ezurlalias_ml USING btree ("action", id, link);







CREATE INDEX ezurlalias_ml_actt ON ezurlalias_ml USING btree (action_type);







CREATE INDEX ezurlalias_ml_actt_org_al ON ezurlalias_ml USING btree (action_type, is_original, is_alias);







CREATE INDEX ezurlalias_ml_id ON ezurlalias_ml USING btree (id);







CREATE INDEX ezurlalias_ml_par_act_id_lnk ON ezurlalias_ml USING btree (parent, "action", id, link);







CREATE INDEX ezurlalias_ml_par_lnk_txt ON ezurlalias_ml USING btree (parent, link, text);







CREATE INDEX ezurlalias_ml_par_txt ON ezurlalias_ml USING btree (parent, text);







CREATE INDEX ezurlalias_ml_text ON ezurlalias_ml USING btree (text, id, link);







CREATE INDEX ezurlalias_ml_text_lang ON ezurlalias_ml USING btree (text, lang_mask, parent);







CREATE INDEX ezuser_role_contentobject_id ON ezuser_role USING btree (contentobject_id);







CREATE INDEX ezuser_role_role_id ON ezuser_role USING btree (role_id);







CREATE INDEX ezwaituntildateevalue_wf_ev_id_wf_ver ON ezwaituntildatevalue USING btree (workflow_event_id, workflow_event_version);







CREATE INDEX ezworkflow_process_process_key ON ezworkflow_process USING btree (process_key);








ALTER TABLE ONLY ezapprove_items
    ADD CONSTRAINT ezapprove_items_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezbasket
    ADD CONSTRAINT ezbasket_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezbinaryfile
    ADD CONSTRAINT ezbinaryfile_pkey PRIMARY KEY (contentobject_attribute_id, "version");







ALTER TABLE ONLY ezcollab_group
    ADD CONSTRAINT ezcollab_group_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezcollab_item
    ADD CONSTRAINT ezcollab_item_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezcollab_item_group_link
    ADD CONSTRAINT ezcollab_item_group_link_pkey PRIMARY KEY (collaboration_id, group_id, user_id);







ALTER TABLE ONLY ezcollab_item_message_link
    ADD CONSTRAINT ezcollab_item_message_link_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezcollab_item_participant_link
    ADD CONSTRAINT ezcollab_item_participant_link_pkey PRIMARY KEY (collaboration_id, participant_id);







ALTER TABLE ONLY ezcollab_item_status
    ADD CONSTRAINT ezcollab_item_status_pkey PRIMARY KEY (collaboration_id, user_id);







ALTER TABLE ONLY ezcollab_notification_rule
    ADD CONSTRAINT ezcollab_notification_rule_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezcollab_profile
    ADD CONSTRAINT ezcollab_profile_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezcollab_simple_message
    ADD CONSTRAINT ezcollab_simple_message_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezcontent_language
    ADD CONSTRAINT ezcontent_language_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezcontentbrowsebookmark
    ADD CONSTRAINT ezcontentbrowsebookmark_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezcontentbrowserecent
    ADD CONSTRAINT ezcontentbrowserecent_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezcontentclass
    ADD CONSTRAINT ezcontentclass_pkey PRIMARY KEY (id, "version");







ALTER TABLE ONLY ezcontentclass_attribute
    ADD CONSTRAINT ezcontentclass_attribute_pkey PRIMARY KEY (id, "version");







ALTER TABLE ONLY ezcontentclass_classgroup
    ADD CONSTRAINT ezcontentclass_classgroup_pkey PRIMARY KEY (contentclass_id, contentclass_version, group_id);







ALTER TABLE ONLY ezcontentclass_name
    ADD CONSTRAINT ezcontentclass_name_pkey PRIMARY KEY (contentclass_id, contentclass_version, language_id);







ALTER TABLE ONLY ezcontentclassgroup
    ADD CONSTRAINT ezcontentclassgroup_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezcontentobject
    ADD CONSTRAINT ezcontentobject_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezcontentobject_attribute
    ADD CONSTRAINT ezcontentobject_attribute_pkey PRIMARY KEY (id, "version");







ALTER TABLE ONLY ezcontentobject_link
    ADD CONSTRAINT ezcontentobject_link_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezcontentobject_name
    ADD CONSTRAINT ezcontentobject_name_pkey PRIMARY KEY (contentobject_id, content_version, content_translation);







ALTER TABLE ONLY ezcontentobject_trash
    ADD CONSTRAINT ezcontentobject_trash_pkey PRIMARY KEY (node_id);







ALTER TABLE ONLY ezcontentobject_tree
    ADD CONSTRAINT ezcontentobject_tree_pkey PRIMARY KEY (node_id);







ALTER TABLE ONLY ezcontentobject_version
    ADD CONSTRAINT ezcontentobject_version_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezcurrencydata
    ADD CONSTRAINT ezcurrencydata_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezdiscountrule
    ADD CONSTRAINT ezdiscountrule_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezdiscountsubrule
    ADD CONSTRAINT ezdiscountsubrule_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezdiscountsubrule_value
    ADD CONSTRAINT ezdiscountsubrule_value_pkey PRIMARY KEY (discountsubrule_id, value, issection);







ALTER TABLE ONLY ezenumobjectvalue
    ADD CONSTRAINT ezenumobjectvalue_pkey PRIMARY KEY (contentobject_attribute_id, contentobject_attribute_version, enumid);







ALTER TABLE ONLY ezenumvalue
    ADD CONSTRAINT ezenumvalue_pkey PRIMARY KEY (id, contentclass_attribute_id, contentclass_attribute_version);







ALTER TABLE ONLY ezforgot_password
    ADD CONSTRAINT ezforgot_password_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezgeneral_digest_user_settings
    ADD CONSTRAINT ezgeneral_digest_user_settings_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezimage
    ADD CONSTRAINT ezimage_pkey PRIMARY KEY (contentobject_attribute_id, "version");







ALTER TABLE ONLY ezimagefile
    ADD CONSTRAINT ezimagefile_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezimagevariation
    ADD CONSTRAINT ezimagevariation_pkey PRIMARY KEY (contentobject_attribute_id, "version", requested_width, requested_height);







ALTER TABLE ONLY ezinfocollection
    ADD CONSTRAINT ezinfocollection_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezinfocollection_attribute
    ADD CONSTRAINT ezinfocollection_attribute_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezisbn_group
    ADD CONSTRAINT ezisbn_group_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezisbn_group_range
    ADD CONSTRAINT ezisbn_group_range_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezisbn_registrant_range
    ADD CONSTRAINT ezisbn_registrant_range_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezkeyword
    ADD CONSTRAINT ezkeyword_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezkeyword_attribute_link
    ADD CONSTRAINT ezkeyword_attribute_link_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezmedia
    ADD CONSTRAINT ezmedia_pkey PRIMARY KEY (contentobject_attribute_id, "version");







ALTER TABLE ONLY ezmessage
    ADD CONSTRAINT ezmessage_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezmodule_run
    ADD CONSTRAINT ezmodule_run_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezmultipricedata
    ADD CONSTRAINT ezmultipricedata_pkey PRIMARY KEY (id);







ALTER TABLE ONLY eznode_assignment
    ADD CONSTRAINT eznode_assignment_pkey PRIMARY KEY (id);







ALTER TABLE ONLY eznotificationcollection
    ADD CONSTRAINT eznotificationcollection_pkey PRIMARY KEY (id);







ALTER TABLE ONLY eznotificationcollection_item
    ADD CONSTRAINT eznotificationcollection_item_pkey PRIMARY KEY (id);







ALTER TABLE ONLY eznotificationevent
    ADD CONSTRAINT eznotificationevent_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezoperation_memento
    ADD CONSTRAINT ezoperation_memento_pkey PRIMARY KEY (id, memento_key);







ALTER TABLE ONLY ezorder
    ADD CONSTRAINT ezorder_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezorder_item
    ADD CONSTRAINT ezorder_item_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezorder_status
    ADD CONSTRAINT ezorder_status_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezorder_status_history
    ADD CONSTRAINT ezorder_status_history_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezpackage
    ADD CONSTRAINT ezpackage_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezpaymentobject
    ADD CONSTRAINT ezpaymentobject_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezpdf_export
    ADD CONSTRAINT ezpdf_export_pkey PRIMARY KEY (id, "version");







ALTER TABLE ONLY ezpolicy
    ADD CONSTRAINT ezpolicy_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezpolicy_limitation
    ADD CONSTRAINT ezpolicy_limitation_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezpolicy_limitation_value
    ADD CONSTRAINT ezpolicy_limitation_value_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezpreferences
    ADD CONSTRAINT ezpreferences_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezproductcategory
    ADD CONSTRAINT ezproductcategory_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezproductcollection
    ADD CONSTRAINT ezproductcollection_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezproductcollection_item
    ADD CONSTRAINT ezproductcollection_item_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezproductcollection_item_opt
    ADD CONSTRAINT ezproductcollection_item_opt_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezrole
    ADD CONSTRAINT ezrole_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezrss_export
    ADD CONSTRAINT ezrss_export_pkey PRIMARY KEY (id, status);







ALTER TABLE ONLY ezrss_export_item
    ADD CONSTRAINT ezrss_export_item_pkey PRIMARY KEY (id, status);







ALTER TABLE ONLY ezrss_import
    ADD CONSTRAINT ezrss_import_pkey PRIMARY KEY (id, status);







ALTER TABLE ONLY ezsearch_object_word_link
    ADD CONSTRAINT ezsearch_object_word_link_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezsearch_return_count
    ADD CONSTRAINT ezsearch_return_count_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezsearch_search_phrase
    ADD CONSTRAINT ezsearch_search_phrase_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezsearch_word
    ADD CONSTRAINT ezsearch_word_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezsection
    ADD CONSTRAINT ezsection_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezsession
    ADD CONSTRAINT ezsession_pkey PRIMARY KEY (session_key);







ALTER TABLE ONLY ezsite_data
    ADD CONSTRAINT ezsite_data_pkey PRIMARY KEY (name);







ALTER TABLE ONLY ezsubtree_notification_rule
    ADD CONSTRAINT ezsubtree_notification_rule_pkey PRIMARY KEY (id);







ALTER TABLE ONLY eztipafriend_counter
    ADD CONSTRAINT eztipafriend_counter_pkey PRIMARY KEY (node_id, requested);







ALTER TABLE ONLY eztrigger
    ADD CONSTRAINT eztrigger_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezurl
    ADD CONSTRAINT ezurl_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezurlalias
    ADD CONSTRAINT ezurlalias_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezurlalias_ml
    ADD CONSTRAINT ezurlalias_ml_pkey PRIMARY KEY (parent, text_md5);







ALTER TABLE ONLY ezurlwildcard
    ADD CONSTRAINT ezurlwildcard_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezuser
    ADD CONSTRAINT ezuser_pkey PRIMARY KEY (contentobject_id);







ALTER TABLE ONLY ezuser_accountkey
    ADD CONSTRAINT ezuser_accountkey_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezuser_discountrule
    ADD CONSTRAINT ezuser_discountrule_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezuser_role
    ADD CONSTRAINT ezuser_role_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezuser_setting
    ADD CONSTRAINT ezuser_setting_pkey PRIMARY KEY (user_id);







ALTER TABLE ONLY ezuservisit
    ADD CONSTRAINT ezuservisit_pkey PRIMARY KEY (user_id);







ALTER TABLE ONLY ezvatrule
    ADD CONSTRAINT ezvatrule_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezvatrule_product_category
    ADD CONSTRAINT ezvatrule_product_category_pkey PRIMARY KEY (vatrule_id, product_category_id);







ALTER TABLE ONLY ezvattype
    ADD CONSTRAINT ezvattype_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezview_counter
    ADD CONSTRAINT ezview_counter_pkey PRIMARY KEY (node_id);







ALTER TABLE ONLY ezwaituntildatevalue
    ADD CONSTRAINT ezwaituntildatevalue_pkey PRIMARY KEY (id, workflow_event_id, workflow_event_version);







ALTER TABLE ONLY ezwishlist
    ADD CONSTRAINT ezwishlist_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezworkflow
    ADD CONSTRAINT ezworkflow_pkey PRIMARY KEY (id, "version");







ALTER TABLE ONLY ezworkflow_assign
    ADD CONSTRAINT ezworkflow_assign_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezworkflow_event
    ADD CONSTRAINT ezworkflow_event_pkey PRIMARY KEY (id, "version");







ALTER TABLE ONLY ezworkflow_group
    ADD CONSTRAINT ezworkflow_group_pkey PRIMARY KEY (id);







ALTER TABLE ONLY ezworkflow_group_link
    ADD CONSTRAINT ezworkflow_group_link_pkey PRIMARY KEY (workflow_id, group_id, workflow_version);







ALTER TABLE ONLY ezworkflow_process
    ADD CONSTRAINT ezworkflow_process_pkey PRIMARY KEY (id);








