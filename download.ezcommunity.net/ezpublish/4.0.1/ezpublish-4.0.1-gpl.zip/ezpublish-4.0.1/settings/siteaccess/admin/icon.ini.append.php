<?php /* #?ini charset="utf8"?

[IconSettings]
# The admin interface uses a different icon set
Theme=crystal-admin
Size=normal

[ActionIcons]
# The admin interface has some action icons in this theme
Theme=ezadmin

*/ ?>
