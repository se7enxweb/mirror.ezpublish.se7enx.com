# Names of callable user defined functions for wrap_user_func.
# Note that they must be defined in separate files under userfunctions directory.
[UserFunctions]
## PermittedFunctionList[]
PermittedFunctionList[]=escapeJsString
PermittedFunctionList[]=getFormatNumericDecimal
PermittedFunctionList[]=getXMLString
