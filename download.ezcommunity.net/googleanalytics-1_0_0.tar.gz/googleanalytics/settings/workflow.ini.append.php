<?php /* #?ini charset="iso-8859-1"?
# eZ publish configuration file for workflows.

[EventSettings]
RepositoryDirectories[]=extension/googleanalytics/workflowtypes
ExtensionDirectories[]=googleanalytics
AvailableEventTypes[]=event_ezreceipt

*/ ?>
