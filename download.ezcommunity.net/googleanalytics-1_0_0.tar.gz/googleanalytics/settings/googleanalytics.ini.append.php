<?php /* #?ini charset="iso-8859-1"?

[GoogleAnalyticsWorkflow]
OrderSubmitToGoogle=enabled
PageSubmitToGoogle=enabled
Urchin=UA-994200-0
HostName=disabled
# Script=https://ssl.google-analytics.com/urchin.js
Script=http://www.google-analytics.com/urchin.js
# Views=shop/reciept;content/view;
DebugMode=disabled
TestMode=disabled
ShopName=mycustomshopname

*/ ?>
