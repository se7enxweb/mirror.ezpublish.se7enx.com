<?php
class googleanalyticsInfo
{
    function info()
    {
        return array(
            'Name' => "<a href='http://ez.no/community/contribs/workflow/google_analytics'>Google Analytics</a>",
            'Version' => "1.0.0",
            'Copyright' => "Copyright (C) 2001 - 2007 <a href='http://brookinsconsulting.com/'>Brookins Consulting</a>",
            'Author' => "Brookins Consulting",
            'License' => "GNU General Public License"
        );
    }
}
?>