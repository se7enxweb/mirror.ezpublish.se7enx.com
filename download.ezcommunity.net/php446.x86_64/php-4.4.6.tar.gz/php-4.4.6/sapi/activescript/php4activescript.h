/*
   +----------------------------------------------------------------------+
   | PHP Version 4                                                        |
   +----------------------------------------------------------------------+
   | Copyright (c) 1997-2007 The PHP Group                                |
   +----------------------------------------------------------------------+
   | This source file is subject to version 3.01 of the PHP license,      |
   | that is bundled with this package in the file LICENSE, and is        |
   | available through the world-wide-web at the following url:           |
   | http://www.php.net/license/3_01.txt                                  |
   | If you did not receive a copy of the PHP license and are unable to   |
   | obtain it through the world-wide-web, please send a note to          |
   | license@php.net so we can mail you a copy immediately.               |
   +----------------------------------------------------------------------+
   | Authors: Wez Furlong <wez@thebrainroom.com>                          |
   +----------------------------------------------------------------------+
 */
/* $Id: php4activescript.h,v 1.2.4.1.8.2 2007/01/01 09:46:51 sebastian Exp $ */

extern zend_module_entry php_activescript_module;
extern sapi_module_struct activescript_sapi_module;
extern HINSTANCE module_handle;
extern void activescript_error_func(int type, const char *error_msg, ...);
extern void activescript_error_handler(int type, const char *error_filename,
		const uint error_lineno, const char *format, va_list args);
