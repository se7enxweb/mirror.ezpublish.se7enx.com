this is the PHP-bundled version of expat 1.95.1

changes from the original version:
- include <php_config.h> instead of <config.h>
- include "php_compat.h" for namespace protection
- hardcode version in xmlparse.c
- stripped off all unneded files


thies@thieso.net, 11th May, 2001

