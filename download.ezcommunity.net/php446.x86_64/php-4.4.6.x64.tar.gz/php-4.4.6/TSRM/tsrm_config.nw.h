#ifndef TSRM_CONFIG_NW_H
#define TSRM_CONFIG_NW_H

#define HAVE_UTIME 1

/* Though we have alloca(), this seems to be causing some problem with the stack pointer -- hence not using it */
/* #define HAVE_ALLOCA 1 */

#endif
