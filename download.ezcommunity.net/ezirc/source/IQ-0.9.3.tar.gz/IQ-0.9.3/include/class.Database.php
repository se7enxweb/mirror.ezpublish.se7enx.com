<?php
class Database {
	// establishes a connection to the database defined in the configuration file in $link, or dies.
	// returns: 1 if successful, else 0.
	function Database($server,$username,$password,$database,$type="postgres") {
		if ($this->link) {
			return 1;
		}
	
		if ($type=="postgres") {
			$this->link=pg_connect("host=$server dbname=$database user=$username password=$password");
			if (!$this->link) {
				die("<b>Connection to the Postgres server failed</b><br />\n");
				return 0;
			}
		}
		elseif ($type=="mysql") {
			$this->link=mysql_connect($server,$username,$password);
			if (!$this->link) {
				die("<b>Connection to MySQL server failed</b><br />\n");
				return 0;
			}
			else {
				if (!@mysql_select_db($database)) {
					die("<b>Connection to MySQL database failed</b><br />\n");
					return 0;
				}
			}
		}
		else {
			die("<b>Unknown database type for DBConnect()</b><br />\n");
			return 0;
		}
		return 1;
	}
	
	// Queries SQL server
	// returns: result of query
	function query($sql,$type="postgres") {
		if ($type=="postgres") {
			$result=@pg_query($this->link,$sql);
		}
		elseif ($type=="mysql") {
			$result=@mysql_query($sql,$this->link);
		}
		
		if (!$result) {
			if ($type=="postgres") {
				$error=pg_last_error($this->link);
			}
			elseif ($type=="mysql") {
				$error=mysql_error($this->link);
			}
			if ($error) {
				echo "[DB error] ($error): $sql";
			}
			echo "\n";
		}		
		return $result;
	}
	
	// Fetches database array for a result
	// returns: result	
	function fetchArray($result,$type="postgres") {
		if ($type=="postgres") {
			$array=@pg_fetch_array($result);
		}
		elseif ($type=="mysql") {
			$array=@mysql_fetch_array($result);
		}
		return $array;
	}
}
?>
