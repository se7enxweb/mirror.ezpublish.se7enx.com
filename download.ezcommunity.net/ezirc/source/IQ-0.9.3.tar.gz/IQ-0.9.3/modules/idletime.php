<?php
$this->bind("pubm","","","<prefix>idle ","pub_idletime");	
$this->bind("raw","","301","","idlemod_away");
$this->bind("raw","","317","","idlemod_idle");
$this->bind("raw","","402","","idlemod_notconn");

$this->functions["idlemod_notconn"]=create_function('$args','
	global $bot;
	$nick=strtolower(gettok($args["in"],3));
	if ($bot->data["idletime"][$nick]) {
		$bot->msg($bot->data["idletime"][$nick]["target"],"\'$nick\' is not connected.");
		unset($bot->data["idletime"][$nick]);
	}
');


$this->functions["pub_idletime"]=create_function('$args','
	global $bot;
	$who=strtolower(gettok($args["extmsg"],0));
	$bot->data["idletime"][$who]=array("target" => $args["target"]);
	$bot->raw("WHOIS $who $who");
');

$this->functions["idlemod_away"]=create_function('$args','
	global $bot;
	$nick=strtolower(gettok($args["in"],3));
	$awaymsg=substr(etc(split(" ",$args["in"]),4),1);
	if ($bot->data["idletime"][$nick]) {
		$bot->data["idletime"][$nick]["awaymsg"]=$awaymsg;
	}
');

$this->functions["idlemod_idle"]=create_function('$args','
	global $bot;
	$nick=strtolower(gettok($args["in"],3));
	$idle=gettok($args["in"],4);
	$signon=gettok($args["in"],5);
	if ($bot->data["idletime"][$nick]) {
		$msg=$nick;
		if ($bot->data["idletime"][$nick]["awaymsg"]) { $msg.=" (away: {$bot->data["idletime"][$nick]["awaymsg"]})"; }
		$msg.=" idle for ".duration ($idle,1);
		$msg.=" connected for ".duration(time()-$signon,1);
		$bot->msg($bot->data["idletime"][$nick]["target"],$msg);
		unset($bot->data["idletime"][$nick]);
	}
	else {
		//print_r($bot->data["idletime"]);
	}
');

$this->infoLog("Idletime module loaded.");
?>
