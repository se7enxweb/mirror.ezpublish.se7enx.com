<?php
$this->bind("pubm","","","<prefix>phone ","reverse_phone_lookup");

$this->functions["reverse_phone_lookup"]=create_function('$args','
	global $bot;
	$number=ereg_replace("[^0-9]","",$args["extmsg"]);
	if (strlen($number) != 10) {
		$bot->msg($args["target"],"Provide a valid 10 digit US phone number.");
		return;
	}
	if ($foo=HTTPGet("http://whitepages.com/search/Reverse_Phone?phone=$number")) {
		$foo=join("",$foo);
		ereg("<img src=\"/static/common/trans.gif\" width=\"1\" height=\"12\" border=\"0\">(.+)<br></span><img",$foo,$result);
		$result=strip_tags(str_replace("<br>","\n",$result[1]));
		$result=ereg_replace("[\t ]+"," ",$result);
		$result=ereg_replace("\n "," ",$result);
		$result=ereg_replace("\n+",", ",trim($result));
		$result=str_replace("&amp;","&",$result);
		if (!trim($result)) {
			$bot->msg($args["target"],"No results.");
		}
		else {
			$bot->msg($args["target"],$result);
		}
	}
	else {
		$bot->msg($args["target"],"Connection failed.");
	}
');

$this->infoLog("Whitepages module loaded");
?>
