<?php
// Acronym Finder module for IQ (http://f0rked.com/IQ)
// version: 2.0
// author: f0rked
// This script will search acronym finder for a given acronym and
// return the top three results

$this->bind("pubm","","","<prefix>acro ",'acronymfinder');

$this->functions["acronymfinder"]=create_function('$args','
	global $bot;
	$fp = fsockopen("www.acronymfinder.com",80,$errno,$errstr,10);
	if (!$fp) { 
		$bot->msg($args["target"],"Could not connect"); 
	}
	else	{
		$query=$args["extmsg"];
		$limit=0;
		$max=3; // max number of results to return
		$buffering=false; // turn buffering on or off (true/false)
		fputs($fp,"GET /af-query.asp?String=exact&Acronym=$query&Find=Find HTTP/1.0\n");
		fputs($fp,"Host: www.acronymfinder.com\n");
		fputs($fp,"User-Agent: Mozilla/4.0 (compatible;)\n");
		fputs($fp,"\n");
			while (!feof($fp)) {
			$buffer=fgets($fp,4096);
			//echo $buffer;
			if (eregi("Sorry, <b>",$buffer)) { 
				$bot->msg($args["target"],trim(strip_tags($buffer)),1,$buffering); 
			}
			if (eregi("valign=\"middle\" width=\"15%\"",$buffer)) { 
				$watch=trim(strip_tags($buffer)); 
			}
			if (eregi("valign=\"middle\" width=\"75%\"",$buffer)) {
				$bot->msg($args["target"],"$watch: ".trim(strip_tags($buffer)),1,$buffering);
				$limit++;
				if ($limit == $max) { break; }
			}
		}
		fclose($fp);
	}
');

$this->infoLog("Acronym Finder module loaded");
?>