<?php
// Dictionary module for IQ (http://f0rked.com/IQ)
// version: 2.0
// author: f0rked
// Define and spell check words (will work with google module if it is loaded)

$this->bind("pubm","","","<prefix>define",'dictionary');
$this->bind("pubm","","","<prefix>spell",'dictspell');
	
$this->functions["dictionary"]=create_function('$args','
	global $bot;
	$word=$args["extmsg"];
	if (gettok($word,0)=="5p311") { 
		$word=etc(split(" ",$word),1); 
		$spell=1;
	}
	if (gettok($word,0)=="-j") { 
		$word=etc(split(" ",$word),1); 
		$db="jargon"; 
	}
	
	$max=10; // max number of lines to spit out per definition
	$db=($db) ? $db : "wn"; // wordnet database
	
	$fp=@fsockopen("dict.org",2628,$one,$two,5);
	if (!$fp) {
		$bot->msg($args["target"],"Could not connect to dictionary.");
	}
	else {
		fputs($fp,"DEFINE $db \"$word\"\n");
		while (!feof($fp)) {
			$buffer = fgets($fp,4096);
			if (gettok($buffer,0," ") == "151") {
				$echo = 1;
				$output = "";
				$limit = 0;
				continue;
			}
			
			// spellcheck failed, try google if google module is available
			if (gettok($buffer,0," ") == "552") {
				if ($spell && $bot->objects["google"]) {
					$result = $bot->objects["google"]->getSpellingSuggestion($word);
					if ($result) {
						$bot->msg($args["target"],$result);
						break;
					}
				}
				$bot->msg($args["target"],"Could not find \'$word\'");
				break;
			}
			
			if (trim($buffer) == ".") {
				unset($echo);
				continue;
			}
			
			if ($echo == "1") {
				if (substr($buffer,0,1)!=" ") {
					$buffer = chr(2).trim($buffer).chr(2);
				}
				if (substr($buffer,0,6)=="      ") {
					$output.=" ".trim($buffer);
				}
				else {
					$output.="\n".trim($buffer);
				}
			}
			
			if (gettok($buffer,0," ") == "250") {
				break;
			}
		}
		
		if ($spell == "1") { 
			if (ereg($word,$output)) { 
				$bot->msg($args["target"],"\'$word\' is spelled correctly."); 
			}
		}
		
		else { 
			$split = split("\n",trim($output));
			for ($i=0;$i<=($max - 1);$i++) {
				if ($split[$i]) { 
					$bot->msg($args["target"],$split[$i]); 
				}
			}
			if (count($split) > $max) { 
				$bot->msg($args["target"],"[buffer control activated]"); 
			}
		}		
		fclose ($fp);
	}
');
	
$this->functions["dictspell"]=create_function('$args','
	global $bot;
	$args["extmsg"]="5p311 ".$args["extmsg"];
	$bot->functions["dictionary"]($args);
');
	
$this->infoLog("Dictionary module loaded");
?>
