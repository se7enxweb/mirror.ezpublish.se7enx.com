<?php

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/geshi/autoloads/ezgeshioperator.php',
                                    'class' => 'eZGeSHiOperator',
                                    'operator_names' => array( 'geshi_hl' ) );

?>
