<?php /* #?ini charset="iso-8859-1"?

[SimpleTagsOperator]
Extensions[]=geshi

IncludeList[]=geshi_functions.php

TagList[php_code]=;;geshi_hl_php
TagList[shell_code]=;;geshi_hl_shell
TagList[c_code]=;;geshi_hl_c
TagList[cpp_code]=;;geshi_hl_cpp
TagList[css_code]=;;geshi_hl_css
TagList[html_code]=;;geshi_hl_html
TagList[js_code]=;;geshi_hl_js
TagList[java_code]=;;geshi_hl_java
TagList[lisp_code]=;;geshi_hl_lisp
TagList[perl_code]=;;geshi_hl_perl
TagList[python_code]=;;geshi_hl_python
TagList[sql_code]=;;geshi_hl_sql
TagList[xml_code]=;;geshi_hl_xml
TagList[eztemplate_code]=;;geshi_hl_eztemplate

*/ ?>
