<?php /* #?ini charset="iso-8859-1"?

[literal]
AvailableClasses[]=php_code
AvailableClasses[]=shell_code
AvailableClasses[]=ini_code
AvailableClasses[]=c_code
AvailableClasses[]=cpp_code
AvailableClasses[]=css_code
AvailableClasses[]=html_code
AvailableClasses[]=js_code
AvailableClasses[]=java_code
AvailableClasses[]=lisp_code
AvailableClasses[]=perl_code
AvailableClasses[]=python_code
AvailableClasses[]=sql_code
AvailableClasses[]=xml_code
AvailableClasses[]=eztemplate_code

*/ ?>
