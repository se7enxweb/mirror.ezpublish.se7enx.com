<?php /* #?ini charset="iso-8859-1"?

[ExtensionSettings]
DesignExtensions[]=geshi

[StylesheetSettings]
CSSFileList[]=geshi.css

*/ ?>
