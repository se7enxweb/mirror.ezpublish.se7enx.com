<?php
// Google module for IQ (http://f0rked.com/IQ)
// version: 2.0
// author: f0rked
// Search google and use google's spell checking features.
// YOU MUST HAVE A DEVELOPER KEY. You can get one from google.com. They're free.
// SOAP is also required for this module to work correctly, run "pear install -f soap"
// to install it.

// Enter your google developer key
$this->info["googlekey"]="x49/NvhFAKEKEY";

/* code */
// load SOAP_Google class or die!
require_once("include/SOAP_Google.php");

$this->objects["google"] = new SOAP_Google($this->info["googlekey"]);

$this->bind("pubm","","","<prefix>g ",'google');	
$this->bind("pubm","","","<prefix>g1 ",'google');
$this->bind("pubm","","","<prefix>g2 ",'google');
$this->bind("pubm","","","<prefix>g3 ",'google');
$this->bind("pubm","","","<prefix>g4 ",'google');
$this->bind("pubm","","","<prefix>g5 ",'google');
$this->bind("pubm","","","<prefix>gcalc ",'gcalc');
$this->bind("pubm","","","<prefix>calc ",'gcalc');
$this->bind("pubm","","","<prefix>c ",'gcalc');
$this->bind("pubm","","","<prefix>gspell ",'gspell');

$this->functions["google"]=create_function('$args','
	global $bot;		
	$params=array(
		"query" => $args["extmsg"],
	);
	
	print_r($args);
	
	$foo="";
	if (ereg($foo."g$",gettok($args["msg"],0))) {
		$maxresults=1;
	}
	elseif (ereg($foo."g1$",gettok($args["msg"],0))) {
		$maxresults=1;
	}
	elseif (ereg($foo."g2$",gettok($args["msg"],0))) {
		$maxresults=2;
	}
	elseif (ereg($foo."g3$",gettok($args["msg"],0))) {
		$maxresults=3;
	}
	elseif (ereg($foo."g4$",gettok($args["msg"],0))) {
		$maxresults=4;
	}
	elseif (ereg($foo."g5$",gettok($args["msg"],0))) {
		$maxresults=5;
	}
	else {
		$maxresults=3;
	}
	
	$result=$bot->objects["google"]->search($params);
	if ($result !== false) {
		$rcount=$result->estimatedTotalResultsCount;
		$time=$result->searchTime;
		
		//$bot->msg($args["target"],"Found $rcount results in $time seconds.");
		
		for ($i=0;$i<=$maxresults-1;$i++) {
			$url=$result->resultElements[$i]->URL;
			$desc=str_replace("<b>",chr(002),$result->resultElements[$i]->snippet);
			$desc=str_replace("</b>",chr(002),$desc);
			$title=str_replace("<b>",chr(002),$result->resultElements[$i]->title);
			$title=str_replace("</b>",chr(002),$title);
			$title=str_replace("&#39;","\'",$title);			
						
			if ($url) {
				$x=$i+1;
				$bot->msg($args["target"],"$title: $url",1,false);
			}
		}
	}
	
	if (!$result->estimatedTotalResultsCount) {
		$bot->msg($args["target"],"No results.",1,false);
	}
');

$this->functions["gcalc"]=create_function('$args','
	global $bot;
	$query=$args["extmsg"];
	$query=str_replace("+","%2B",$query);
	$query=str_replace(" ","+",$query);
			
	$fp=fsockopen("google.com",80,$err1,$err2,5);
	if (!$fp) {
		$bot->msg($args["target"],"Could not start calculator, {$args["nick"]}.",1,false);
	}
	else {
		fputs($fp,"GET /search?hl=en&ie=UTF-8&oe=UTF-8&q=$query&btnG=Google+Search HTTP/1.0\n");
		fputs($fp,"Host: www.google.com\n\n");
		while (!feof($fp)) {
			$buffer=fgets($fp,4096);
			//echo $buffer;
			if (ereg("calc_img.gif",$buffer)) {
				ereg("<td nowrap><font size=\+1><b>(.+)</b></td>",$buffer,$result);
				$result=$result[1];
				$result=str_replace("<sup>","^",$result);
				$result=str_replace("&times;","x",$result);
				$result=strip_tags($result);
				$bot->msg($args["target"],$result,1,false);
				break;
			}
		}
		if (!$result) {
			$bot->msg($args["target"],"No luck, {$args["nick"]}, sorry.",false);
		}
	}
');

$this->functions["gspell"]=create_function('$args','
	global $bot;
	$result=$bot->objects["google"]->getSpellingSuggestion($args["extmsg"]);
	
	if ($result) {
		$bot->msg($args["target"],$result,1,false);
	}
	else {
		$bot->msg($args["target"],"No suggestion.",1,false);
	}
');

$this->infoLog("Google module loaded");
?>
