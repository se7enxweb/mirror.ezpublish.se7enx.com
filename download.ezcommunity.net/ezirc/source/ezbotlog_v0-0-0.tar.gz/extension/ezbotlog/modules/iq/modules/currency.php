<?php
$this->bind("pubm","","","<prefix>cur(rency)? ","pub_currency");

$this->functions["pub_currency"]=create_function('$args','
	global $bot;
	if (!eregi("^[0-9\.]+ [a-z]{3} [a-z]{3}$",$args["extmsg"])) {
		$bot->msg($args["target"],"Syntax: <amount> <from currency> <to currency>  Example: 125 USD EUR");
		return;
	}
	$amount=gettok($args["extmsg"],0);
	$from=strtoupper(gettok($args["extmsg"],1));
	$to=strtoupper(gettok($args["extmsg"],2));
	
	$bot->log("from: $from to: $to amount: $amount");

	$data=join("\n",HTTPGet("http://www.xe.com/ucc/convert.cgi?Amount=$amount&From=$from&To=$to"));
	if (ereg("1 $from = ([0-9\.]+) $to",$data,$regs)) {
		$conv=$regs[1];
		$value=$conv*$amount;
		$bot->msg($args["target"],"$amount $from = $value $to (1 $from = $conv $to)");
	}
	else {
		$bot->msg($args["target"],"Provided currencies not recognized.");
	}
');
?>
