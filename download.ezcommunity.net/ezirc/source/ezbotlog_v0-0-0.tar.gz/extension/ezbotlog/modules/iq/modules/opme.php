<?php	
$this->bind("pubm","o","","^opme","opme");
	
$this->functions["opme"]=create_function('$args','
	// print_r($args) // do this if you want to see the argument array sent to the function
	// global $bot so can use it
	global $bot;
	// $args["extmsg"] is a string containing all words after the first in the message
	// select the chan to op the user in
	$chan=($args["extmsg"]) ? strtolower($args["extmsg"]) : $args["target"]; 	
	
	// determine if the bot is an OP and the user is in the channel requested
	// if, so op the user.
	if ($bot->info["channel_users"][$chan][$bot->info["mynick"]]["modes"]["o"] && $bot->info["channel_users"][$chan][$args["nick"]]) {
		$bot->mode($chan,"+o {$args["nick"]}");
	}
');

$this->infoLog("Opme module loaded");
?>
