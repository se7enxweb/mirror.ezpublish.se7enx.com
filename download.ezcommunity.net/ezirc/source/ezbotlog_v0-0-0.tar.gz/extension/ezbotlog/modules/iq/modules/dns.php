<?php
// DNS module for IQ (http://f0rked.com/IQ)
// version: 2.0
// author: f0rked
// Perform DNS functions

$this->bind("pubm","","","<prefix>dns ",'dns');
$this->bind("pubm","","","<prefix>rdns ",'rdns');
$this->bind("pubm","","","<prefix>host ",'dns');

$this->functions["dns"]=create_function('$args','
	global $bot;

	$host=gettok($args["extmsg"],0);
	$server=gettok($args["extmsg"],1);
	foreach (array_keys($bot->info["channel_users"]) as $foochan) {
		if ($bot->info["channel_users"][$foochan][$host]["host"]) {
			$host=$bot->info["channel_users"][$foochan][$host]["host"];
			break;
		}
	}
	if (!ereg("^[0-9a-zA-Z\.\-]+$",$host)) {
		$bot->msg($args["target"],"Invalid argument");
		return;
	}
	if ($server && !ereg("^[0-9a-zA-Z\.\-]+$",$server)) {
		$bot->msg($args["target"],"Invalid argument");
		return;
	}
	$exec=(strlen($server) > 1) ? "host \'$host\' \'$server\'" : "host $host";
	
	$result=split("\n",shell_exec($exec));
	
	foreach ($result as $line) {
		$s = split(" ",$line);
		if ($s[0] == "Name:") {
			$r_servername=$s[1];
		}
		if ($s[0] == "Address:") {
			$r_address=$s[1];
		}
		if (ereg("has address",$line) || ereg("not found",$line) || ereg("domain name pointer",$line)) {
			$append=($r_servername) ? " (using: $r_servername::$r_address)" : "";
			$bot->msg($args["target"],"$line$append");
		}
	}
');

$this->functions["rdns"]=create_function('$args','
	global $bot;
	$host=gettok($args["msg"],1);
	
	if (ereg("^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$",$host)) {
		// $host is an ip address
		$type="ip";
		$result1=gethostbyaddr($host);
	}
	else {
		// other.
		$type="name";
		$result1=gethostbyname($host);
	}
	
	if ($result1==$host) {
		$bot->msg($args["target"],"Failed to resolve \'$host\'.",1,false);
	}
	else {
		if ($type=="ip") {
			$result2=gethostbyname($result1);
		}
		else {
			$result2=gethostbyaddr($result1);
		}
		
		$output="$host -> $result1";
		
		if ($result2==$result1) {
			$output.=". Failed to resolve \'$result1\'.";
		}
		else {
			$output.=" -> $result2";
		}
		
		$bot->msg($args["target"],$output,1,false);
	}
');

$this->infoLog("DNS module loaded");
?>