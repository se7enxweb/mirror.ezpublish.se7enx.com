<?php
// Gametiger module for IQ (http://f0rked.com/IQ)
// version: 2.0
// author: f0rked
// Return results from gametiger.net about CS players and servers

$this->bind("pubm","","","<prefix>gt ",'gametiger');
$this->bind("pubm","","","<prefix>gametiger ",'gametiger');

$this->functions["gametiger"]=create_function('$args','
	global $bot;
	$game="cstrike";
	$type=gettok($args["msg"],1," ");
	$query=str_replace(" ","+",etc(split(" ",$args["msg"]),2));
	$found=0;

	$types=array("server","map","player","address");
	if (!in_array($type,$types)) { 
		$bot->msg($args["target"],"[gt] first argument must be one of the following: ".join(", ",$types)); 
		return;
	}
		
	$fp=@fsockopen("www.gametiger.net",80,$errno,$errstr,5);
	if (!$fp) {
		$bot->msg($args["target"],"Could not connect to gametiger.net");
	}
	else {
		fputs($fp,"GET /search?game=cstrike&$type=$query&count=10 HTTP/1.0\n");
		fputs($fp,"Host: www.gametiger.net\n");
		fputs($fp,"User-Agent: Mozilla 3.0 (Compatible)\n\n");
		while (!feof($fp)) {
			$buffer=fgets($fp,4096);
			$buffer=str_replace("&nbsp;"," ",$buffer);
		
			if ($type == "address") {
				if (ereg("Server Details",$buffer)) { $startchecking = 1; }
				if ($startchecking == 1) {
					$string = strip_tags($buffer,"<td>");
					$string = str_replace("<td bgcolor=CCCCCC>","<td>",$string);
					$string = str_replace("</td>","",$string);
					$string = substr($string,4);
					$string = str_replace("&lt;","<",$string);
					$string = str_replace("&gt;",">",$string);
					$string_array = split("<td>",$string);
					$string_array[2] = trim($string_array[2]);
					$string_array[1] = trim($string_array[1]);
					if ($string_array[1] == "Server Name") { $name = $string_array[2]; }
					if ($string_array[0] == "IP:Port") { $ip = $string_array[1]; }
					if ($string_array[0] == "Engine") { $engine = $string_array[1]; }
					if ($string_array[0] == "Game") { $game = $string_array[1]; }
					if ($string_array[0] == "Map") { $map = $string_array[1]; }
					if ($string_array[0] == "Last Map Change") { $lastmapchange = $string_array[1]; }
					if ($string_array[0] == "Protocol Version") { $protocol = $string_array[1]; }
					if ($string_array[0] == "Type of Server") { $typeofserver = $string_array[1]; }
					if ($string_array[0] == "OS") { $os = $string_array[1]; }
					if ($string_array[0] == "Password required") { $passwordreq = $string_array[1]; }
					if ($string_array[0] == "Active/Max Players  ") { $players = $string_array[1]; }	
					if ($string_array[0] == "Last Check") { $lastcheck = $string_array[1]; }
					if ($string_array[0] == "Bogo Ping") { 
						$ping = $string_array[1]."ms"; 
						$bot->msg($args["target"],"[gt] $name ($ip)($map)($typeofserver)($os)($players)($ping)"); 
					}
				}
			}
			
			if (ereg("href=/search",$buffer)) {
				$string = strip_tags($buffer,"<td>");
				$string = str_replace("<td align=right>","<td>",$string);
				$string = str_replace("</td>","",$string);
				$string = substr($string,4);
				$string = str_replace("&lt;","<",$string);
				$string = str_replace("&gt;",">",$string);
				$string_array = split("<td>",$string);
				if ($found < 3) {
					if (($type == "server") || ($type == "map")) {
						$name = trim($string_array[0]);
						$ip = $string_array[1];
						$game = $string_array[2];
						$map = trim($string_array[3]);
						$players = $string_array[4];
						$lastcheck = $string_array[5];
						$bot->msg($args["target"],"[gt] $name ($ip)($map)($players)");
						$found++;
					}
					elseif ($type == "player") {
						$player = $string_array[0];
						$name = trim($string_array[1]);
						$ip = $string_array[2];
						$game = $string_array[3];
						$map = $string_array[4];
						$players = $string_array[5];
						$lastcheck = $string_array[6];
						$bot->msg($args["target"],"[gt] $player ($name)($ip)($map)($players)");
						$found++;
					}
				}
			}
			if (ereg("ff3333>no such",$buffer)) {
				$bot->msg($args["target"],"[gt] " . trim(strip_tags($buffer)));
			} 
			if (ereg("Error: can not connect to database!",$buffer)) {
				$bot->msg($args["target"],"[gt] " . trim(strip_tags($buffer)));
			}
		}
	}
');

$this->infoLog("Gametiger module loaded");
?>