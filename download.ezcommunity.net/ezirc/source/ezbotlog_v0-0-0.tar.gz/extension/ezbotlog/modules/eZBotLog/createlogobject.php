<?php
//
// Created on: <20-Apr-2005 16:30:00 gb>
//
// Copyright (C) 2005-2006 Brookins Consulting. All rights reserved.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE included in
// the packaging of this file.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@brookinsconsulting.com if any conditions of this licencing isn't clear to
// you.
//
// Note: This is almost entirely cut-n-pasted code from content/action with 
// a lot of stuff removed and one small section added by Nathan Sharp 
// Which was used by Graham Brookins to build this module...

include_once( 'kernel/classes/ezcontentobject.php' );
include_once( 'kernel/classes/ezcontentobjecttreenode.php' );

include_once( 'kernel/classes/ezcontentbrowse.php' );
include_once( 'kernel/classes/ezcontentbrowsebookmark.php' );
include_once( 'kernel/classes/ezcontentclass.php' );

include_once( 'lib/ezutils/classes/ezhttptool.php' );
include_once( 'ezobjectcreator.php' );

/////////////////////////////////////////////////

function createLogObject( $date, $text ) {

$http =& eZHTTPTool::instance();

// $module =& $Params["Module"];
$module = array( 'name' => 'eZBotLog' );



/////////////////////////////////////////////////
// kracker: condition do the whole thing ?
// kracker: defaults / overrides (posts) ...
 
// Requirements: 

// ClassID : 47
// ClassIdentifier :  irc_log_entry
// NodeID : 468 (ini setting) 
// log file container / mangment ... (folders in folders? or (single folder view / with threashold//  switches ( std, week, month, 60 days, 90 days, 180 days, search 
// Create Dated Folders (Show Notes + Items Per Day Configuration (Abstraction / Hiding from Users ?)


/////////////////////////////////////////////////
// settings : replace with ini

// ezbotlog content type / position 
$classID = 47;
$classIdentifier = 'irc_log_entry';
$nodeID = 468;

// ezbotlog : eZ publish : irc bot [User] 
$userNodeID = 472;

$default_author='ezbotlog';
$default_content='$log_string';
$default_posted='2005-04-24';

$author_name_2453 = 'ezbotlog';
$author_id = 0;
$author_email = 'ezbotlog@ezpublishhosting.com';


/////////////////////////////////////////////////
echo( "\n\n ................................................... \n\n");
// die ("entering ... the creator init() ");


/*

<input class="box" name="ContentObjectAttribute_data_author_name_2453[]" value="graham brookins" type="text">
<input name="ContentObjectAttribute_data_author_id_2453[]" value="0" type="hidden">
<input class="box" name="ContentObjectAttribute_data_author_email_2453[]" value="info@brookinsconsulting.com" type="text">
<input name="ContentObjectAttribute_id[]" value="2453" type="hidden">

<input class="button" name="CustomActionButton[2453_remove_selected]" value="Delete selected" title="Remove selected rows from the author list." type="submit">
<input class="button" name="CustomActionButton[2453_new_author]" value="Add author" title="Add a new row to the author list." type="submit">

////////////////////////////////

edit page and have the option to change the value there, of course.

<input type="hidden" name="default_attributename" value="some value" />

Where attributename is the name of the attribute (not the number). Note
that it does't take quite the same format as the usual edit pages. For example,
to set a date attribute, you'd just use something like:

<input type="hidden" name="default_date" value="2005-04-24" />
*/


/////////////////////////////////////////////////

$dependanciesCheck = true;

//  exit();
// why would you not log
if ( $dependanciesCheck ) {

    // set base variables 
    $hasClassInformation = false;
    $contentClassID = false;
    $contentClassIdentifier = false;
    $class = false;

    ////
    // replace post variables with local + external hooks / settings

    if ( $classID )
    {
        $contentClassID = $classID;
        if ( $contentClassID )
            $hasClassInformation = true;
    }
    else if ( $classIdentifier )
    {
        $contentClassIdentifier = $classIdentifier;
        $class =& eZContentClass::fetchByIdentifier( $contentClassIdentifier );
        if ( is_object( $class ) )
        {
            $contentClassID = $class->attribute( 'id' );
            if ( $contentClassID )
                $hasClassInformation = true;
        }
    }


    echo ( $classID. " | $hasClassInformation | $classIdentifier | $nodeID \n" );

    ///////////////////////////////////////////
    // get ready to create the objects, make sure, here we go ...
    if ( $hasClassInformation && $nodeID ) 
    { 

      $node =& eZContentObjectTreeNode::fetch( $nodeID );

      if ( $node  ) { 
	echo "# __ node is empty __ ###################################################################################### \n";
      }

       echo "\n ########## is_object( $node ) will we ? pass here ... ################ \n\n\n ";

        if ( is_object( $node ) )
        {
            $parentContentObject =& $node->attribute( 'object' );

	    echo "\n\n\n ########## !!!!!!!!! will not pass permissions check, why? fail ...  ################ \n\n\n ";

// check permissions
if ( $parentContentObject->checkAccess( 'create', $contentClassID,  $parentContentObject->attribute( 'contentclass_id' ) ) == '1' ) 
{ 
 	      echo "\n\n\n ########## will not pass permissions check, why? fail ...  ################ \n\n\n ";

	        // which user doing the dirty?
	        // /users/editors/ezlog_ez_publish_irc_bot

                // $user =& eZUser::currentUser();
  	        $userID = $userNodeID; // & $user->attribute( 'contentobject_id' );

                $sectionID = $parentContentObject->attribute( 'section_id' );

		echo "\n\n\n ########## will pass here ??? ################ \n\n\n ";

                if ( !is_object( $class ) )
                    $class =& eZContentClass::fetch( $contentClassID );

                if ( is_object( $class ) )
                {
		    // really creating chaos ... now()
                    $contentObject =& $class->instantiate( $userID, $sectionID );
                    $nodeAssignment =& eZNodeAssignment::create( 
 		      array(
                       'contentobject_id' => $contentObject->attribute( 'id' ),
                       'contentobject_version' => $contentObject->attribute( 'current_version' ),
                       'parent_node' => $node->attribute( 'node_id' ),
                       'is_main' => 1
                      )
                    );


                    ///////////////////////////////////////////////////////
		    // don't think this is needed?
		    //                    if ( $http->hasPostVariable( 'AssignmentRemoteID' ) )
		    if ( $assignmentRemoteID )
                    {
                        $nodeAssignment->setAttribute( 'remote_id', $assignmentRemoteID );
                    }
                    $nodeAssignment->store();


                    // NPS: -----------------------------------
                    // Create default values if found.

                    // $post_vars =& $http->attribute('post');



		    ///////////////////////////////////////////////////////
		    $obj_creator =& new eZObjectCreator();

                    // Set status to draft for the content object version
                    $content_object_version =& $contentObject->version( $contentObject->attribute( 'current_version' ) );

                    $content_object_version->setAttribute( 'status', EZ_VERSION_STATUS_DRAFT);
                    $content_object_version->store();            

                    // replacement?

                    // Assign the attributes
                    $content_attributes =& $content_object_version->contentObjectAttributes();
                    
                    foreach( $content_attributes as $content_attribute )
                    {
                       // Each attribute has an attribute called 'identifier' that identifies it.
                       $attribute_identifier = $content_attribute->attribute("contentclass_attribute_identifier");

                       // $post_key = "default_".$attribute_identifier;
                       $post_key = eval($attribute_identifier);

		       print($post_key . "\n");
             
		       // if ( $http->hasPostVariable($post_key)) 
                       if ( $post_key ) 
                       {
			 $post_val = $post_key; // $http->postVariable($post_key);
                           $obj_creator->importAttribute($post_val, $content_attribute);
                       }
                    }
                    // NPS: -------------------------------

                    // no redirection, just silent positive exit status ... 
                    // $module->redirectTo( 'content/edit/' . $contentObject->attribute( 'id' ) . '/' . $contentObject->attribute( 'current_version' ) );
		    //

                    return;
                }
                else
                {
		  //     return $module->handleError( EZ_ERROR_KERNEL_ACCESS_DENIED, 'kernel' );
                }
            }
            else
            {
	      //   return $module->handleError( EZ_ERROR_KERNEL_ACCESS_DENIED, 'kernel' );
            }
        }
        else
        {
	  // return $module->handleError( EZ_ERROR_KERNEL_NOT_AVAILABLE, 'kernel' );
        }
    
    }

}

// needed ...

// return module contents
/*
$Result = array();
$Result['content'] =& $result;
*/

}

?>