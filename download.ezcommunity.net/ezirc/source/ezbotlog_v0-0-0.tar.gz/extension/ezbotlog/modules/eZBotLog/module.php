<?php
//
// Created on: <20-Apr-2005>
//
// Copyright (C) 2005 Brookins Consulting. All rights reserved.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE included in
// the packaging of this file.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//

$Module = array( 'name' => 'eZBotLog' );

$ViewList = array();
$ViewList['createlogobject'] = array(
'script' => 'createlogobject.php' );

?>
