<?php
/*
MoloBot 0.5 Beta
By Jordan Smith - jordan@codedemons.net
Please see the readme.txt for more information
*/
//
// Configs
// Specify the channels you want the bot to connect to.
// (You can enter as many or as few as needed)
// $channels = array("#ezpublish", "#php", "#mysql");
// $channels = array("#ezpublish", "#php");
$channels = array("#ezpublish");

// Server to connect to
$server = "zelazny.freenode.net"; // "irc.freenode.net";

// Port to connect to. Default: 6667
$port = "6667"; 

// The bot's nick
// $nick = "MoloBot".rand(0,99);
$nick = "ezlog-lstnr-".rand(0,99);

// Bot's name
$name = $nick;

// Enable logging by default? 
// (can always be changed later with the .logging command)
$logging = 1; // 1 to enable, 0 to disable

// Visit google.com/api to get your developer key.
// I can't search without it.
$google_key = "pY2Y3fdQFHKc5bZPZ5N5fAIq5Th9tgzB";

//
// Although easily understood, the below code is meant for people
// who know PHP.
//
set_time_limit(0);
error_reporting(E_ALL ^ E_NOTICE);

include "molobot.class.php";
$molobot = new MB_Core($server, $nick, $port, $name);
$molobot->logging_enable($logging);
$molobot->google_key = $google_key;

while ($molobot->reconnect)
{
	$molobot->connect();
	
	/*
	foreach ($channels as $chan)
		$molobot->join($chan);
	*/

        $molobot->join("#ezpublish");

		
	$molobot->listen(); // Only leaves this if we/servers die.
	
	// Delay 30 seconds before reconnect, if we are reconnecting
	if (! $molobot->reconnect)
	{
		echo "Terminating.\n";
		break;
	}	
	
	echo "Delaying 30 seconds before reconnect.\n";
	sleep(30);
	// Clean some connection vars in preparation for connect.
	$molobot->clean();
}
?>