MoloBot 0.5 Beta
By Jordan Smith

===================================================
Documentation
===================================================

MoloBot is an IRC bot written in PHP that is capable of connecting to IRC channels and responding to user commands. Its features can be divided into three groups:
    - User invoked commands over IRC
    - Admin invoked commands over IRC (after login)
    - Hard-coded (i.e. logging)

MoloBot is a rewrite of the bot in a tutorial I wrote for CodeDemons.net and employs many of the same techniques. If you are wondering about how to write such a bot from scratch, or have trouble with the concept, please see that tutorial at: http://www.CodeDemons.net/tutorials/PHP/Your-Own-IRC-Bot

***************************************************
IMPORTANT:
If you intend to use the .search function you will need to enter your own key to have access to the Google API. In u_search() you must change the $key to your developer key that Google will give you when you sign up for the API. google.com/api

To take advantage of the remote admin features you must edit the "passwords.txt" file in the bot's main directory.
***************************************************

WANT A FUNCTION?
See the bottom of this file for contact information.

===================================================
END-USER NOTES
===================================================

---------------------------------------------------
HOW TO RUN
---------------------------------------------------

To run the bot, download and install PHP from www.php.net. Then, run it from the command line like so:
C:\path\to\php.exe -q path\to\molobot.php

---------------------------------------------------
USER FUNCTIONS
---------------------------------------------------
These are denoted by a u_ prefix in the source code.
They can be called from within a channel by: .function_name

.time
Displays current time

.noob <username>
Displays welcome message for beginners to channel

.oppm
Provides reminder not to PM OPs

.search <query>
Returns Google's first result.

.php <query>
Same as .search but only searches PHP.net

.cd <query>
Same as .search but only searches codedemons.net

.help
Displays a list of functions as defined in the function.

---------------------------------------------------
ADMIN FUNCTIONS
---------------------------------------------------
These functions are only available to logged in users (with the exception of .login itself). In the same folder as the bot, edit the "passwords.txt" file to  
change the users who can login.

.restart
After sending the QUIT command, MoloBot will reconnect

.logging <0 = off, 1 = on>
Toggle logging on or off

.logout
Log out

.disconnect
Send the QUIT command to the server and do not reconnect

.pm <person> <message>
Sends the PM <message> to <person>

.say <#channel> <message>
Sends <message> to <#channel>. MoloBot must be in <#channel>

.part <#channel>
Part from <#channel>

.join <#channel>
Joins <#channel>

.identify <authserv> <handle> <password>
Identifies with authserv. Most authservs should support this (tested on GameSurge). If not, you can always use .pm to send exactly the message you need.

.login <username> <password>
Logs administrator in. <username> and <password> are defined in the "passwords.txt" file.

===================================================
DEVELOPER NOTES
===================================================

Files: molobot.class.php (the heart of the bot)
       molobot.php (example use of the class)
       nusoap.php (soap library required by the Google API implementation)
       passwords.txt (username,password combinations for admin features)
       logs.txt (duh)
       RUN_MOLOBOT.bat (Will run MoloBot on windows systems by calling the php cli included)

Currently there is only one class: MB_Core. I am considering moving user functions to another class at some point.

MoloBot comes with an example usage, but I will explain some of the key functions here. Before we begin, I want to make it clear that although this bot will eventually be targeted for novice users wanting a bot in their channel (s), at this point it is intended for developers. Most channels do not like random people bringing bots into channels, so make sure that you get the appropriate permission.

Reading the tutorial at CodeDemons.net/tutorials/PHP/Your-Own-IRC-Bot will help you understand the concept of connecting to an IRC channel and receiving/sending messages. Please do not bother me with questions that are answered in that tutorial.

Before asking "how do I..." please check the RFC 1459. This RFC details everything you need to know about the IRC protocol. All servers and clients speak this language. RFC 1459 is like a dictionary for IRC. Although it is not entertaining reading, it will answer many questions: http://www.faqs.org/rfcs/rfc1459.html

With that being said, if you have problems with the bot, I would like to hear about it. If you have a feature request, please tell me. Bear in mind that I will not code a feature that I think will only be used by one or two people. Only request features if you think many users will benefit from them.

If you do not understand IRC, you should not be coding a bot that uses it, so I will not answer questions about using IRC, or IRC commands.

I will not answer general questions about PHP; those can be answered in the channel #php on irc.gamesurge.net.

I will answer questions about the bot as long as they have not already been answered in the forums: http://www.codedemons.net/forums.

You can contact me via email at jordan@codedemons.net

Best of luck!
Jordan Smith

jordan@codedemons.net
www.codedemons.net