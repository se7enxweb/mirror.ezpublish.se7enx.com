<?php
/*
[ExtensionSettings]
DesignExtensions[]=ObjectCreator
*/
?>
