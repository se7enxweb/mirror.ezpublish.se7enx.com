<?php
/*
[ModuleSettings]
ExtensionRepositories[]=ObjectCreator
*/
?>
