<?php
/*

[ExtensionSettings]
DesignExtensions[]=ezbotlog

*/
?>
