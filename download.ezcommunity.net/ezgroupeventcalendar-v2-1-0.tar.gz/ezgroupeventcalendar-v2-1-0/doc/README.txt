eZGroupEventCalendar
Version : 2.0.0

Updated By: Graham Brookins : Brookins Consulting : <info|at|brookinsconsulting|dot|com>
Created By: Adam Fallert <FallertA@umsystem.edu>
Updated on: <Nov-2004 11:00:00>
Created on: <Oct-2001 14:36:00>


LICENCE               (see doc/LICENCE for official licence)
############################################################

These source files are part of eZ publish 2, web publishing software,
and developed for the eZ publish 2 community
Copyright � 2004 Graham Brookins | Brookins Consulting

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, US

INSTALATION
############################################################
For installation instructions and suggestions see doc/INSTALL

INTRODUCTION
############################################################
For packages dependancies, history, references, etc see doc/INTRODUCTION

BUGS
############################################################
If you are having problems, check doc/BUGS for the issue, solution and background information about the issue.

CREDITS
############################################################
For package release history, history, notes, references, see doc/CREDITS

SUPPORT
############################################################
When The installation, introduction documentation has failed
to yeild an answere to your question, you may seek support from
one of these sources of eZ publish 2 support.

(Community) eZ publish 2 Support | Documentation : http://ezcommunity.net/forum
(Commercial) eZ publish 2 Support | Development : http://brookinsconsulting.com/



