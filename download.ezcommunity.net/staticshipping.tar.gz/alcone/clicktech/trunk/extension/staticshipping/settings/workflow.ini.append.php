[EventSettings]
ExtensionDirectories[]=staticshipping
AvailableEventTypes[]=event_ezadvancedshipping

[SimpleShippingWorkflow]
FreeShipping=Enabled
FreeShippingPrice=50.00
FreeShippingWeightDiscount=5.00
eZoption2ProductVariations=Enabled
ShippingVendorName=Alcone
