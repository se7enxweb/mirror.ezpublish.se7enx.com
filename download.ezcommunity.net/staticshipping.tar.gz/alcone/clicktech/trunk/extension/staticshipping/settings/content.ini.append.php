[DataTypeSettings]
ExtensionDirectories[]=staticshipping
AvailableDataTypes[]=ezshipping