[ExtensionSettings]
DesignExtensions[]=staticshipping