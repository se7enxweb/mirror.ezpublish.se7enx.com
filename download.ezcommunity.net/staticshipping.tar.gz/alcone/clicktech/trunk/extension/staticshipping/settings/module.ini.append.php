[ModuleSettings]
ExtensionRepositories[]=staticshipping
