var theme =
[
	['<IMG SRC=folder.gif> ', '<IMG SRC=folderopen.gif> '],
	['', ''],
	['', ''],
	'<IMG SRC=page.gif> ',
	['', ''],
	['&nbsp;&nbsp;&nbsp;&nbsp;', '&nbsp;&nbsp;&nbsp;&nbsp;'],
];
